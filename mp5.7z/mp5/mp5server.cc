/*************************************************************************
* mp5server.cc -- waits for a client  to play a game of Tic-tac-toe
*
*  Usage: mp5server
*
*
*  Author:     Terrence Bradley Janas
*  Course:     CS 323 (Operating Systems Design)
*  Assignment: MP5 (Client/Server Network System)
*  Date:       May 5, 2003
*
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <iostream.h>

#define PORT 5249    // the server's port number
#define BACKLOG 1
#define BOARDSIZE 9  // there are 9 tiles on a Tic-tac-toe board

int main(void)
{
  int sockfd, new_fd;        // listen on sock_fd, new connection on new_fd
  struct sockaddr_in my_addr;    // my address information
  struct sockaddr_in their_addr; // connector's address information
  struct hostent* he;
  int sin_size;
  int yes = 1;
  void* buf;                     // read/write() buffer for TCP socket
  char input;                    // user input on the server-side
  short position;                // translation from ASCII to int of input
  short freespaces = BOARDSIZE;  // how many spaces are left on the board?
  char gameBoard[BOARDSIZE];

  gameBoard[0] = '1';            // Initialize the gameboard
  gameBoard[1] = '2';
  gameBoard[2] = '3';            // When a space is taken, it will
  gameBoard[3] = '4';            // be marked as 'X' if it was the
  gameBoard[4] = '5';            // server's move, or 'O' if it was
  gameBoard[5] = '6';            // the client's move
  gameBoard[6] = '7';
  gameBoard[7] = '8';
  gameBoard[8] = '9';


  // create a socket used for accepting incoming connections
  if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
    perror("socket");
    exit(1);
  }

  if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1) {
    perror("setsockopt");
    exit(1);
  }


  my_addr.sin_family = AF_INET;         // host byte order
  my_addr.sin_port = htons(PORT);       // short, network byte order
  my_addr.sin_addr.s_addr = INADDR_ANY; // automatically fill with my IP
  memset(&(my_addr.sin_zero), '\0', 8); // zero the rest of the struct

  // bind the socket to IP,PORT
  if (bind(sockfd,(struct sockaddr *)&my_addr,sizeof(struct sockaddr))==-1) {
    perror("bind");
    exit(1);
  }

  printf("Binding to port %d.\n", PORT);

  // wait for incoming connections
  if (listen(sockfd, BACKLOG) == -1) {
     perror("listen");
     exit(1);
  }

  printf("Waiting for client...\n");

  sin_size = sizeof(struct sockaddr_in);

  // accept incoming client... only accept one client
  if ((new_fd = accept(sockfd, (struct sockaddr *)&their_addr, &sin_size)) < 0)
  {
    perror("accept");
    exit(1);
  }

  // find the NS translation for client's IP address, if one exists
  he = gethostbyaddr( (const char*)&their_addr.sin_addr,
                       sizeof(struct in_addr),AF_INET );

  if (he != NULL)  // able to perform translation
    printf("Connection received from %s...\n",he->h_name);
  else             // NOT able to perform translation
    printf("Connection received from %s...\n",inet_ntoa(their_addr.sin_addr));

  close(sockfd);  // we don't need this listening socket anymore


  // initialize temporary gameboard to send to client
  buf = malloc(BOARDSIZE);
  if (buf == NULL) {
    fprintf(stderr,"Cannot initialize game board: memory error!\n");
    exit(1);
  }


  while(1)   // this is the main gameplay loop
  {
    printf("\n");
    printf(" %c | %c | %c\n",gameBoard[0],gameBoard[1],gameBoard[2]);
    printf("---+---+---\n");
    printf(" %c | %c | %c\n",gameBoard[3],gameBoard[4],gameBoard[5]);
    printf("---+---+---\n");
    printf(" %c | %c | %c\n",gameBoard[6],gameBoard[7],gameBoard[8]);
    printf("\n");


    // get valid input from the user at the server-side
    cout << "Please choose a position: ";
    while( !(cin >> input) )
      cin.sync();

    // note: ASCII valus of '1' is 49, ASCII value of '9' is 57
    while ( ((int)input < 49) || ((int)input > 57) ) {
      cin.sync();
      while( !(cin >> input) )
        cin.sync();
    }

    // translate the ASCII input char into an int
    position = ((int)input)-48;

    // ok, is the position we want taken? if so, pick another one
    while ((gameBoard[position-1]=='X') || (gameBoard[position-1]=='O')) {
      cout << "Position taken; choose again: ";
      cin.sync();
      while(!(cin >> input))
        cin.sync();
      while ( ((int)input < 49) || ((int)input > 57) ) {
        cin.sync();
        while( !(cin >> input) )
          cin.sync();
      }
      position = ((int)input)-48;
    }

    // piece was chosen successfully, write it to the board
    gameBoard[position-1] = 'X';
    freespaces--;

    // copy the game board to buffer for xmit to client
    memcpy(buf,gameBoard,BOARDSIZE);

    // Send the current game board to the client.
    // We could get away with sending just the piece that changes,
    // but there's no real performance gain. Not much different between
    // 1 and 9 bytes compared to TCP overhead.
    if (write(new_fd, buf, BOARDSIZE) < 0)
    {
      perror("write");
      close(new_fd);
      free(buf);
      exit(1);
    }


     // check to see if server won. all winning possibilities are checked
     if ( ((gameBoard[0]==gameBoard[1])&&(gameBoard[1]==gameBoard[2])) ||
          ((gameBoard[3]==gameBoard[4])&&(gameBoard[4]==gameBoard[5])) ||
          ((gameBoard[6]==gameBoard[7])&&(gameBoard[7]==gameBoard[8])) ||

          ((gameBoard[0]==gameBoard[3])&&(gameBoard[3]==gameBoard[6])) ||
          ((gameBoard[1]==gameBoard[4])&&(gameBoard[4]==gameBoard[7])) ||
          ((gameBoard[2]==gameBoard[5])&&(gameBoard[5]==gameBoard[8])) ||

          ((gameBoard[0]==gameBoard[4])&&(gameBoard[4]==gameBoard[8])) ||
          ((gameBoard[2]==gameBoard[4])&&(gameBoard[4]==gameBoard[6]))
        )
     {
       // The server has won, print the final gameboard and disconnect.
       printf("\n");
       printf(" %c | %c | %c\n",gameBoard[0],gameBoard[1],gameBoard[2]);
       printf("---+---+---\n");
       printf(" %c | %c | %c\n",gameBoard[3],gameBoard[4],gameBoard[5]);
       printf("---+---+---\n");
       printf(" %c | %c | %c\n",gameBoard[6],gameBoard[7],gameBoard[8]);
       printf("\n");
       printf("Game over. X WINS!\n");
       close(new_fd);
       printf("Disconnected.\n\n");
       free(buf);
       exit(0);
     }

     // are there any spaces left for client or server?
     if (freespaces == 0) {
       printf("\n");
       printf(" %c | %c | %c\n",gameBoard[0],gameBoard[1],gameBoard[2]);
       printf("---+---+---\n");
       printf(" %c | %c | %c\n",gameBoard[3],gameBoard[4],gameBoard[5]);
       printf("---+---+---\n");
       printf(" %c | %c | %c\n",gameBoard[6],gameBoard[7],gameBoard[8]);
       printf("\n");
       printf("Game over: tie game.\n");
       close(new_fd);
       printf("Disconnected.\n\n");
       free(buf);
       exit(0);
     }


     printf("Waiting for client move...\n");

     // get the client's move
     if ( read(new_fd,buf,BOARDSIZE) < 0 )
     {
       perror("read");
       close(new_fd);
       free(buf);
       exit(1);
     }


     // copy the newly received game board to the current game board
     memcpy(gameBoard,buf,BOARDSIZE);
     freespaces--;


     // check to see if client won. all winning possibilities are checked
     if ( ((gameBoard[0]==gameBoard[1])&&(gameBoard[1]==gameBoard[2])) ||
          ((gameBoard[3]==gameBoard[4])&&(gameBoard[4]==gameBoard[5])) ||
          ((gameBoard[6]==gameBoard[7])&&(gameBoard[7]==gameBoard[8])) ||

          ((gameBoard[0]==gameBoard[3])&&(gameBoard[3]==gameBoard[6])) ||
          ((gameBoard[1]==gameBoard[4])&&(gameBoard[4]==gameBoard[7])) ||
          ((gameBoard[2]==gameBoard[5])&&(gameBoard[5]==gameBoard[8])) ||

          ((gameBoard[0]==gameBoard[4])&&(gameBoard[4]==gameBoard[8])) ||
          ((gameBoard[2]==gameBoard[4])&&(gameBoard[4]==gameBoard[6]))
        )
     {
       // The client has won, print the final gameboard and disconnect.
       printf("\n");
       printf(" %c | %c | %c\n",gameBoard[0],gameBoard[1],gameBoard[2]);
       printf("---+---+---\n");
       printf(" %c | %c | %c\n",gameBoard[3],gameBoard[4],gameBoard[5]);
       printf("---+---+---\n");
       printf(" %c | %c | %c\n",gameBoard[6],gameBoard[7],gameBoard[8]);
       printf("\n");
       printf("Game over. O WINS!\n");
       close(new_fd);
       printf("Disconnected.\n\n");
       free(buf);
       exit(0);
     }
  }    // end of gameplay loop
}


