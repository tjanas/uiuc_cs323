/*************************************************************************
* mp5client.cc -- connects to a server to play a game of Tic-tac-toe
*
*  Usage: mp5client <server_IP_address>
*
*
*  Author:     Terrence Bradley Janas
*  Course:     CS 323 (Operating Systems Design)
*  Assignment: MP5 (Client/Server Network System)
*  Date:       May 5, 2003
*
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <iostream.h>

#define PORT 5249    // the client's port number
#define BACKLOG 1
#define BOARDSIZE 9  // there are 9 tiles on a Tic-tac-toe board

int main(int argc, char *argv[])
{
  int sockfd;                     // TCP socket file descriptor
  struct hostent *he;
  struct sockaddr_in their_addr;  // Connector's address information
  void* buf;                      // read/write() buffer for TCP socket
  char input;                     // Client's move from stdin
  short position;                 // Translation from ASCII to int of input
  short freespaces = BOARDSIZE;   // How many spaces are left on the board?
  char gameBoard[BOARDSIZE];

  gameBoard[0] = '1';            // Initialize the gameboard
  gameBoard[1] = '2';
  gameBoard[2] = '3';            // When a space is taken, it will
  gameBoard[3] = '4';            // be marked as 'X' if it was the
  gameBoard[4] = '5';            // server's move, or 'O' if it was
  gameBoard[5] = '6';            // the client's move
  gameBoard[6] = '7';
  gameBoard[7] = '8';
  gameBoard[8] = '9';

  if ((he=gethostbyname(argv[1])) == NULL) {  // get the host info
    perror("gethostbyname");
    exit(1);
  }

  // create a socket to connect to
  if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
    perror("socket");
    exit(1);
  }

  their_addr.sin_family = AF_INET;          // host byte order
  their_addr.sin_port = htons(PORT);        // short, network byte order
  their_addr.sin_addr = *((struct in_addr *)he->h_addr);
  memset(&(their_addr.sin_zero), '\0', 8);  // zero the rest of the struct


  // connect to the socket
  if (connect(sockfd, (struct sockaddr *)&their_addr, sizeof(struct sockaddr)) == -1) {
    perror("connect");
    exit(1);
  }


  printf("Connected to %s on port %d.\n",argv[1],PORT);


  // initialize temporary gameboard to receive from server
  buf = malloc(BOARDSIZE);
  if (buf == NULL)
  {
    fprintf(stderr,"Cannot initialize game board: memory error!\n");
    exit(1);
  }


  while(1)  // play until the game is over!
  {
    // first, the client receives the server's move
    printf("Waiting for server move...\n");
    if ( read(sockfd,buf,BOARDSIZE) < 0 )
    {
      perror("read");
      close(sockfd);
      free(buf);
      exit(1);
    }

    // Store the gameboard received from the server.
    // This gameboard should have one less free space,
    // since the server just made a move.
    memcpy(gameBoard,buf,BOARDSIZE);
    freespaces--;


    // print the current gameboard
    printf("\n");
    printf(" %c | %c | %c\n",gameBoard[0],gameBoard[1],gameBoard[2]);
    printf("---+---+---\n");
    printf(" %c | %c | %c\n",gameBoard[3],gameBoard[4],gameBoard[5]);
    printf("---+---+---\n");
    printf(" %c | %c | %c\n",gameBoard[6],gameBoard[7],gameBoard[8]);
    printf("\n");


    // check to see if server won
    if ( ((gameBoard[0]==gameBoard[1])&&(gameBoard[1]==gameBoard[2])) ||
         ((gameBoard[3]==gameBoard[4])&&(gameBoard[4]==gameBoard[5])) ||
         ((gameBoard[6]==gameBoard[7])&&(gameBoard[7]==gameBoard[8])) ||

         ((gameBoard[0]==gameBoard[3])&&(gameBoard[3]==gameBoard[6])) ||
         ((gameBoard[1]==gameBoard[4])&&(gameBoard[4]==gameBoard[7])) ||
         ((gameBoard[2]==gameBoard[5])&&(gameBoard[5]==gameBoard[8])) ||

         ((gameBoard[0]==gameBoard[4])&&(gameBoard[4]==gameBoard[8])) ||
         ((gameBoard[2]==gameBoard[4])&&(gameBoard[4]==gameBoard[6]))
       )
    {
      // If the server won, then disconnect from the server and exit.
      printf("Game over! X WINS!\n");
      close(sockfd);
      printf("Disconnected.\n\n");
      free(buf);
      exit(0);
    }


    // If no one has won & and there are no free spaces left,
    // then disconnect from the server and exit.
    if (freespaces == 0) {
      printf("Game over: tie game.\n");
      close(sockfd);
      printf("Disconnected.\n\n");
      free(buf);
      exit(0);
    }

    // Otherwise, we can still keep playing.
    // Now it's the client's turn...
    cout << "Please choose a position: ";
    while(!(cin >> input))
      cin.sync();

    // input can only be a char between '1' and '9'
    while ( ((int)input < 49) || ((int)input > 57) ) {
      cin.sync();
      while(!(cin >> input))
        cin.sync();
    }

    position = ((int)input)-48;  // convert char number to int number

    // Did the client choose a space that is already taken?
    // If so, wait until the client chooses a valid space.
    while ((gameBoard[position-1]=='X') || (gameBoard[position-1]=='O')) {
      cout << "Position taken; choose again: ";
      cin.sync();
      while(!(cin >> input))
        cin.sync();
      while ( ((int)input < 49) || ((int)input > 57) ) {
        cin.sync();
        while( !(cin >> input) )
          cin.sync();
      }
      position = ((int)input)-48;
    }


    // Mark the game board with the client's move,
    // and update the number of free spaces left on the board.
    gameBoard[position-1] = 'O';
    freespaces--;


    // Send the newly updated copy of the gameboard to the server
    memcpy(buf,gameBoard,BOARDSIZE);
    if (write(sockfd, buf, BOARDSIZE) < 0)
    {
      perror("write");
      close(sockfd);
      free(buf);
      exit(1);
    }



    // check to see if client won
    if ( ((gameBoard[0]==gameBoard[1])&&(gameBoard[1]==gameBoard[2])) ||
         ((gameBoard[3]==gameBoard[4])&&(gameBoard[4]==gameBoard[5])) ||
         ((gameBoard[6]==gameBoard[7])&&(gameBoard[7]==gameBoard[8])) ||

         ((gameBoard[0]==gameBoard[3])&&(gameBoard[3]==gameBoard[6])) ||
         ((gameBoard[1]==gameBoard[4])&&(gameBoard[4]==gameBoard[7])) ||
         ((gameBoard[2]==gameBoard[5])&&(gameBoard[5]==gameBoard[8])) ||

         ((gameBoard[0]==gameBoard[4])&&(gameBoard[4]==gameBoard[8])) ||
         ((gameBoard[2]==gameBoard[4])&&(gameBoard[4]==gameBoard[6]))
       )
    {
      // If the client has won, then print out the end resulting
      // game board, and then disconnect from the server
      printf("\n");
      printf(" %c | %c | %c\n",gameBoard[0],gameBoard[1],gameBoard[2]);
      printf("---+---+---\n");
      printf(" %c | %c | %c\n",gameBoard[3],gameBoard[4],gameBoard[5]);
      printf("---+---+---\n");
      printf(" %c | %c | %c\n",gameBoard[6],gameBoard[7],gameBoard[8]);
      printf("\n");
      printf("Game over. O WINS!\n");
      close(sockfd);
      printf("Disconnected.\n\n");
      free(buf);
      exit(0);
    }
  }
}


