#ifndef __TICTACTOE__H__1__
#define __TICTACTOE__H__1__

#include <iostream.h>

class TicTacToe
{
  public:
    TicTacToe();
    virtual ~TicTacToe();

    bool placeX(int pos);
    bool placeY(int pos);

    char getWinner(void);

    ostream &displayBoard(ostream &outs);

  protected:
    char square[3][3];

    bool place(int pos, char player);
    

  private:
};

#endif // __TICTACTOE__H__1__
