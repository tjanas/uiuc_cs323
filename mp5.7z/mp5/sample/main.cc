#include <iostream.h>
#include "tictactoe.h"

int main(int argc, char *argv[])
{
  TicTacToe game;
  char winner;
  int pos;
  bool turn = true;

  while( (winner = game.getWinner()) == '\0' )
  {
    cout << endl;
    game.displayBoard(cout);
    cout << endl;

    if(turn)
    {
      cout << "Player X choose a position: ";
      cin >> pos;
      while(!game.placeX(pos))
      {
        cout << "Position taken; choose again: ";
        cin >> pos;
      }
    }
    else
    {
      cout << "Player Y choose a position: ";
      cin >> pos;
      while(!game.placeY(pos))
      {
        cout << "Position taken; choose again: ";
        cin >> pos;
      }
    }

    turn = !turn;
  }

  cout << endl;
  game.displayBoard(cout);
  cout << endl;
    
  switch(winner)
  {
    case 'X':
      cout << "Game over! X WINS!" << endl;
      break;

    case 'Y':
      cout << "Game over! Y WINS!" << endl;
      break;

    case 'T':
      cout << "Game over; tie game." << endl;
      break;
  }

  return 0;
}
