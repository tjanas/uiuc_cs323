#include <iostream.h>
#include "tictactoe.h"

TicTacToe::TicTacToe()
{
  for(int i=0; i<3; i++)
    for(int j=0; j<3; j++)
      square[i][j]='\0';
}

TicTacToe::~TicTacToe()
{
}

bool TicTacToe::place(int pos, char player)
{
  pos--;
  int col = pos % 3;
  int row = pos / 3;

  if(square[row][col] != '\0')
    return false;

  square[row][col] = player;
  return true;
}

bool TicTacToe::placeX(int pos)
{
  return place(pos, 'X');
}

bool TicTacToe::placeY(int pos)
{
  return place(pos, 'Y');
}

char TicTacToe::getWinner(void)
{
  // check from wins starting in the upper left corner
  if(square[0][0]!='\0')
  {
    if((square[0][0]==square[0][1])&&(square[0][0]==square[0][2]))
      return square[0][0];
    else if((square[0][0]==square[1][1])&&(square[0][0]==square[2][2]))
      return square[0][0];
    else if((square[0][0]==square[1][0])&&(square[0][0]==square[2][0]))
      return square[0][0];
  }

  // check for wins starting from the center
  if(square[1][1]!='\0')
  {
    if((square[1][1]==square[0][1])&&(square[1][1]==square[2][1]))
      return square[1][1];
    else if((square[1][1]==square[1][0])&&(square[1][1]==square[1][2]))
      return square[1][1];
    else if((square[1][1]==square[0][2])&&(square[1][1]==square[2][0]))
      return square[1][1];
  }

  // check for winds starting from the lower right
  if(square[2][2]!='\0')
  {
    if((square[2][2]==square[0][2])&&(square[2][2]==square[1][2]))
      return square[2][2];
    else if((square[2][2]==square[2][0])&&(square[2][2]==square[2][1]))
      return square[2][2];
  }

  // no winner

  // check to see if board if full
  for(int i=0; i<3; i++)
    for(int j=0; j<3; j++)
      if(square[i][j]=='\0') return '\0';

  // board is full -- tie game
  return 'T';
}

ostream &TicTacToe::displayBoard(ostream &outs)
{
  outs << " " << ( square[0][0] == '\0' ? '1' : square[0][0] )
    << " | " << ( square[0][1] == '\0' ? '2' : square[0][1] )
    << " | " << ( square[0][2] == '\0' ? '3' : square[0][2] )
    << endl;
  outs << "---+---+---" << endl;
  outs << " " << ( square[1][0] == '\0' ? '4' : square[1][0] )
    << " | " << ( square[1][1] == '\0' ? '5' : square[1][1] )
    << " | " << ( square[1][2] == '\0' ? '6' : square[1][2] )
    << endl;
  outs << "---+---+---" << endl;
  outs << " " << ( square[2][0] == '\0' ? '7' : square[2][0] )
    << " | " << ( square[2][1] == '\0' ? '8' : square[2][1] )
    << " | " << ( square[2][2] == '\0' ? '9' : square[2][2] )
    << endl;

  return outs;
}
