//     Preemptive Priority scheduling 
//
#include "system.h"
#include "list.h"
#include "testcase.h"
#include "thread.h"

//----------------------------------------------------------------------
// ThreadTest5
//      Preemptive Priority scheduling algorithm
//      Process  Burst Time  Priority  Arrival
//        P1        20         MAX	0
//        P2        29         MAX 	0
//        P3         8         MAX 	0
//        P4        17         MAX	0
//        P5        32         MAX 	0
//----------------------------------------------------------------------

void ThreadTest5()
{
 
    int  numThreads = 5;
    int  startTime[] = {  0,370,450,100,250  };
    int  burstTime[] = { 20, 29,  8, 17, 32  };
    int   priority[] = {  Thread::MAX_PRIORITY,  Thread::MAX_PRIORITY,
                          Thread::MAX_PRIORITY,  Thread::MAX_PRIORITY,
                          Thread::MAX_PRIORITY   };
    schedpair * a_pair;

    List<schedpair *> * procList = new List<schedpair *>();

    for( int i = 0; i < numThreads; i++ ) {
       a_pair = new schedpair;
       a_pair->burst = burstTime[i];
       a_pair->prior = priority[i];
       procList->SortedInsert( a_pair, startTime[i] );
    }

    scheduler->SetSchedPolicy(SCHED_MQ);

    printf("Starting at ");
    stats->PrintElapsedTicks();
    printf("Queuing threads.\n");

    TestScheduler( ( int ) procList );
}

