//     Non-preemptive Priority scheduling 
//
#include "system.h"
#include "list.h"
#include "testcase.h"

//----------------------------------------------------------------------
// ThreadTest3
//      Non-preemptive Priority scheduling algorithm
//      Process  Burst Time  Priority  Arrival
//        P1        20          1	100
//        P2        29          0	  0
//        P3         8          2	150
//        P4        17          4	 70
//        P5        32          1	 30
//----------------------------------------------------------------------

void ThreadTest3()
{
 
    int  numThreads = 5;
    int  startTime[] = {100,  0,150, 70, 30  };
    int  burstTime[] = { 20, 29,  8, 17, 32  };
    int   priority[] = {  1,  0,  2,  4,  1  };
    schedpair * a_pair;

    List<schedpair *> * procList = new List<schedpair *>();

    for( int i = 0; i < numThreads; i++ ) {
       a_pair = new schedpair;
       a_pair->burst = burstTime[i];
       a_pair->prior = priority[i];
       procList->SortedInsert( a_pair, startTime[i] );
    }

    scheduler->SetSchedPolicy(SCHED_PRIO);

    printf("Starting at ");
    stats->PrintElapsedTicks();
    printf("Queuing threads.\n");

    TestScheduler( ( int ) procList );
}

