// synch.cc 
//	Routines for synchronizing threads.  Three kinds of
//	synchronization routines are defined here: semaphores, locks 
//   	and condition variables (the implementation of the last two
//	are left to the reader).
//
// Any implementation of a synchronization routine needs some
// primitive atomic operation.  We assume Nachos is running on
// a uniprocessor, and thus atomicity can be provided by
// turning off interrupts.  While interrupts are disabled, no
// context switch can occur, and thus the current thread is guaranteed
// to hold the CPU throughout, until interrupts are reenabled.
//
// Because some of these routines might be called with interrupts
// already disabled (Semaphore::V for one), instead of turning
// on interrupts at the end of the atomic operation, we always simply
// re-set the interrupt state back to its original value (whether
// that be disabled or enabled).
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "synch.h"
#include "system.h"
#include "list.h"
//----------------------------------------------------------------------
// Semaphore::Semaphore
// 	Initialize a semaphore, so that it can be used for synchronization.
//
//	"debugName" is an arbitrary name, useful for debugging.
//	"initialValue" is the initial value of the semaphore.
//----------------------------------------------------------------------

Semaphore::Semaphore(char* debugName, int initialValue)
{
  name = debugName;
  value = initialValue;
  // implement for mp2
}

//----------------------------------------------------------------------
// Semaphore::Semaphore
// 	De-allocate semaphore, when no longer needed.  Assume no one
//	is still waiting on the semaphore!
//----------------------------------------------------------------------

Semaphore::~Semaphore()
{
  // implement for mp2
}

//----------------------------------------------------------------------
// Semaphore::P  (synonym Semaphore::down)
// 	Wait until semaphore value > 0, then decrement.  Checking the
//	value and decrementing must be done atomically, so we
//	need to disable interrupts before checking the value.
//
//	Note that Thread::Sleep assumes that interrupts are disabled
//	when it is called.
//----------------------------------------------------------------------

void
Semaphore::P()
{
  // implement for mp2
}

//----------------------------------------------------------------------
// Semaphore::V  (synonym Semaphore::up)
// 	Increment semaphore value, waking up a waiter if necessary.
//	As with P(), this operation must be atomic, so we need to disable
//	interrupts.  Scheduler::ReadyToRun() assumes that threads
//	are disabled when it is called.
//----------------------------------------------------------------------

void
Semaphore::V()
{
  // implement for mp2
}



//----------------------------------------------------------------------
// Lock::Lock(char* debugName)
//      Initialize a lock, so that it can be used for synchronization.
//      Initially, unlocked.
//
//      "debugName" is an arbitrary name useful for debugging purposes.
//----------------------------------------------------------------------
Lock::Lock(char* debugName) 
{
  // implement for mp2
}

//----------------------------------------------------------------------
// Lock::~Lock()
//      De-allocate lock, when no longer needed.  Assume no one
//      is still waiting on the lock!
//
//----------------------------------------------------------------------
Lock::~Lock() 
{
  // implement for mp2
}

//----------------------------------------------------------------------
// Lock::Acquire()
//      Atomically wait until the lock is free, then set it to busy.
//      Equivalent to Semaphore::down(), with the semaphore value of 0
//      equal to busy, and semaphore value of 1 equal to free.
//----------------------------------------------------------------------

void Lock::Acquire()
{
  // implement for mp2
}


//----------------------------------------------------------------------
// Lock::Release
//	Atomically set lock to be free, waking up a thread waiting
//	for the lock, if any.
//	Equivalent to Semaphore::up(), with the semaphore value of 0
//	equal to busy, and semaphore value of 1 equal to free.
//
//	By convention, only the thread that acquired the lock
// 	may release it.
//---------------------------------------------------------------------

void Lock::Release()
{
  // implement for mp2
}

//----------------------------------------------------------------------
// Lock::isHeldByCurrentThread()
//      Returns true if currentThread is the holder of the lock.
//      Interrupts should be disabled here.
//----------------------------------------------------------------------

bool Lock::isHeldByCurrentThread()
{
  // implement for mp2
  return false;
}

//----------------------------------------------------------------------
// Condition::Condition
//  Initialize a condition variable, so that it can be 
//  used for synchronization.  Initially, no one is waiting
//  on the condition.
//
//  "debugName" is an arbitrary name, useful for debugging.
//----------------------------------------------------------------------
Condition::Condition(char* debugName)
{
  // implement for mp2
}

//----------------------------------------------------------------------
// Condition::Condition
//  Deallocate the data structures implementing a condition variable.
//----------------------------------------------------------------------
Condition::~Condition()
{
  // implement for mp2
}

//----------------------------------------------------------------------
// Condition::Wait
//  Atomically release monitor lock and go to sleep.
//  Our implementation uses semaphores to implement this, by
//  allocating a semaphore for each waiting thread.  The signaller
//  will up() this semaphore, so there is no chance the waiter
//  will miss the signal, even though the lock is released before
//  calling down().
//
//  Note: we assume Mesa-style semantics, which means that the
//  waiter must re-acquire the monitor lock when waking up.
//
//  "conditionLock" -- lock protecting the use of this condition
//----------------------------------------------------------------------
void Condition::Wait(Lock* conditionLock)
{
  // implement for mp2
}

//----------------------------------------------------------------------
// Condition::Signal
//  Wake up a thread waiting on this condition, if any.
//
//  Note: we assume Mesa-style semantics, which means that the
//  signaller doesn't give up control immediately to the thread
//  being woken up (unlike Hoare-style).
//
//  Also note: we assume the caller holds the monitor lock
//  (unlike what is described in Birrell's paper).  This allows
//  us to access waitQueue without disabling interrupts.
//
//  "conditionLock" -- lock protecting the use of this condition
//----------------------------------------------------------------------

void Condition::Signal(Lock* conditionLock)
{
  // implement for mp2
}

//----------------------------------------------------------------------
// Condition::Broadcast
//  Wake up all threads waiting on this condition, if any.
//
//  "conditionLock" -- lock protecting the use of this condition
//----------------------------------------------------------------------

void Condition::Broadcast(Lock* conditionLock)
{
  // implement for mp2
}
