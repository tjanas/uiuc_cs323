/*
 * test1.c - Perform basic operations on the Nachos file system.
 */

#include "syscall.h"

int main()
{
  char buf[17];
  int fId;

  Write("Testing basic Nachos file system.\n", 34, ConsoleOutput);

  /* create a 20 byte file named TEST1 */
  Create("TEST1", 20);
    
  /* open the file */
  fId = Open("TEST1");

  /* write 17 bytes to the file */
  Write("file system test\n", 17, fId);
    
  /* move back 17 bytes in the file */
  Lseek(fId, -17);
    
  /* read 17 bytes from the file */
  Read(buf, 17, fId);

  /* write 17 bytes to the console */
  Write(buf, 17, ConsoleOutput);
    
  /* close the file */
  Close(fId);

  /* attempt to read from closed file */
  if (Read(buf, 1, fId) == -1) 
    Write("Cannot Read\n", 12, ConsoleOutput); /* this shouldn't work */
    
  /* remove the file */
  Remove("TEST1");

  /* open TEST1 */
  if (Open("TEST1") == -1)
    Write("Cannot Open\n", 12, ConsoleOutput); /* should fail; it was deleted */

  /* stop the machine */
  Halt();
}

