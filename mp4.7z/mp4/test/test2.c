/*
 * test2.c - Check if directories are distinguished from regular files.
 */

#include "syscall.h"

main ()
{
  int status;
  int fId;
  char buf[20];

  /* create a cs323 directory */
  MkNode("cs323");

  /* create a 30 byte file in cs323 called test */
  Create("cs323/test", 30);
  
  /* The status returned should be -1, as 
   * test1 is not a directory, so test2 is not created */
  status = Create("cs323/test/test2", 30);
  if (status == -1)
    Write("test2 is not created\n", 21, ConsoleOutput); 
  else
    Write("Erroneous implementation of MkNode\n", 35, ConsoleOutput);
     
  
  /* creating a directory called test in cs323 should fail since there
   * is a file called test in cs323. */
  status=MkNode("cs323/test");
  if (status == -1)
    Write("Directory test is not created\n", 30, ConsoleOutput); 
  else
    Write("Erroneous implementation of MkNode\n", 35, ConsoleOutput);

  /* create a directory called mp4 in cs323 */
  MkNode("cs323/mp4");

  /* Hmm.... */
  Create("cs323/mp4/tester", 12);
  fId = Open("cs323/mp4/tester");
  Write("test2 broke\n", 12, fId);
  Close(fId);

  /* create a directory called test in mp4 */
  MkNode("cs323/mp4/test");
  
  /* create a 30 byte file called test in cs323/mp4/test */
  Create("cs323/mp4/test/test", 30);

  /* attemp to open the file */
  fId = Open("cs323/mp4/test/test");

  /* it should be able to open the file */
  if(fId == -1)
    Write("Error opening file.\n", 21, ConsoleOutput);
  else
  {
    /* write 12 bytes to the file */
    Write("Deep Access\n", 12, fId);
    
    /* seek back 12 bytes */
    Lseek(fId, -12);

    /* read 12 bytes from the file and display in on the console */
    Read(buf, 12, fId);
    Write(buf, 12, ConsoleOutput);

    /* close the file */
    Close(fId);
  }

  /* halt the machine */
  Halt();
}  
