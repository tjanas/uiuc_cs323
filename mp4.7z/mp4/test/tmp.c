
#include "syscall.h"

int
main()
{
    char buf[17];
    int fId;

    
    Create("TEST1", 20);

    fId = Open("TEST1");
    Write("file system test\n", 17, fId);
    
    
    Lseek(fId, -17);
    
    Read(buf, 17, fId);
    Write(buf, 17, ConsoleOutput);
    
    Close(fId);

    if (Read(buf, 1, fId) == -1) 
      Write("Cannot Read\n",12, ConsoleOutput);
    
    Remove("TEST1");

    if (Open("TEST1") == -1)
      Write("Cannot Open\n", 12, ConsoleOutput);
    

    Halt();
}

