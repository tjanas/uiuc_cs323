/*
 * test4.c - See if links work with directories.
 */

#include "syscall.h"

main ()
{
  int status;
  int fId;
  char buf[20];

  /* create a cs323 directory */
  MkNode("cs323");

  /* create a 30 byte file in cs323 called test */
  Create("cs323/test", 30);
  
  /* The status returned should be -1, as 
   * test1 is not a directory, so test2 is not created */
  status = Create("cs323/test/test2", 30);
  if (status == -1)
    Write("test2 is not created\n", 21, ConsoleOutput); 
  else
    Write("Erroneous implementation of MkNode\n", 35, ConsoleOutput);
     
  
  /* creating a directory called test in cs323 should fail since there
   * is a file called test in cs323. */
  status=MkNode("cs323/test");
  if (status == -1)
    Write("Directory test is not created\n", 30, ConsoleOutput); 
  else
    Write("Erroneous implementation of MkNode\n", 35, ConsoleOutput);

  /* create a directory called mp4 in cs323 */
  MkNode("cs323/mp4");

  /* create a directory called test in mp4 */
  MkNode("cs323/mp4/test");
  
  /* create a 30 byte file called test in cs323/mp4/test */
  Create("cs323/mp4/test/test", 30);

  /* attemp to open the file */
  fId = Open("cs323/mp4/test/test");

  /* it should be able to open the file */
  if(fId == -1)
    Write("Error opening file.\n", 21, ConsoleOutput);
  else
  {
    /* write 12 bytes to the file */
    Write("Deep Access\n", 12, fId);
    
    /* seek back 12 bytes */
    Lseek(fId, -12);

    /* read 12 bytes from the file and display in on the console */
    Read(buf, 12, fId);
    Write(buf, 12, ConsoleOutput);

    /* close the file */
    Close(fId);

    /* Link to this file */
    Link("cs323/short", "cs323/mp4/test/test");

    /* Open the link */
    fId = Open("cs323/short");

    if(fId == -1)
      Write("Error opening link.\n", 21, ConsoleOutput);
    else
    {
      /* write some junk into the buffer */
      buf[0] = 'H';
      buf[1] = 'i';
      buf[2] = ' ';
      buf[3] = 'C';
      buf[4] = 'S';
      buf[5] = '3';
      buf[6] = '2';
      buf[7] = '3';
      buf[8] = '.';
      buf[9] = '\0';
      buf[10] = '\0';
      buf[11] = '\0';

      /* read 12 bytes from the file */
      Read(buf, 12, fId);
      Write(buf, 12, ConsoleOutput);

      /* close the file */
      Close(fId);
    }
    
    /* Open the link again */
    fId = Open("cs323/short");

    /* write 12 bytes to the file */
    Write("C is sexy. \n", 12, fId);

    /* close the file */
    Close(fId);

    /* attemp to open the file again */
    fId = Open("cs323/mp4/test/test");

    /* read 12 bytes from the file */
    Read(buf, 12, fId);
    Write(buf, 12, ConsoleOutput);

    /* close the file */
    Close(fId);

    /* test5 goodness */
    status = MkNode("cs323/tbj");
    if (status == -1)
      Write("MkNode fucked up\n", 17, ConsoleOutput);

    Link("tbjlink", "cs323/tbj");

    status = Create("tbjlink/sting", 30);
    if (status == -1)
      Write("Create fucked up\n", 17, ConsoleOutput);

    status=Remove("cs323/tbj/sting");
    if (status == -1)
      Write("Remove fucked up\n", 17, ConsoleOutput);

    status=RmNode("tbjlink");
    if (status == -1)
      Write("RmNode fucked up\n", 17, ConsoleOutput);

    status=RmNode("cs323/tbj");
    if (status == -1)
      Write("RmNode fucked up\n", 17, ConsoleOutput);
  }

  /* halt the machine */
  Halt();
}  
