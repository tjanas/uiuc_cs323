/*
 * test3.c - Check if hard links work.
 */

#include "syscall.h"

main ()
{
  int status;
  int fId;
  char buf[20];

  /* create a 20 byte file named TEST1 */
  Create("TEST1", 20);
    
  /* open the file */
  fId = Open("TEST1");

  /* write 17 bytes to the file */
  Write("file system test\n", 17, fId);
    
  /* move back 17 bytes in the file */
  Lseek(fId, -17);
    
  /* read 17 bytes from the file */
  Read(buf, 17, fId);

  /* write 17 bytes to the console */
  Write(buf, 17, ConsoleOutput);
    
  /* close the file */
  Close(fId);

  /* link TEST2 to point to the same file as TEST1 */
  status = Link("TEST2", "TEST1");
  if (status == -1)
    Write("Erroneous implementation of Link\n", 33, ConsoleOutput);
  else
  {
    /* should've linked */
    Write("TEST2 is linked\n", 16, ConsoleOutput); 

    /* try to link TEST1 to TEST2 */
    status = Link("TEST1", "TEST2");
    if(status != -1)
      Write("Erroneous implementation of Link\n", 33, ConsoleOutput);
    else
      Write("Failed to link TEST1 to TEST2\n", 30, ConsoleOutput); /* good */

    /* try to link to non-existant file */
    status = Link("TEST4", "TEST3");
    if(status != -1)
      Write("Erroneous implementation of Link\n", 33, ConsoleOutput);
    else
      Write("Failed to link TEST4 to TEST3\n", 30, ConsoleOutput); /* good */
    
    /* remove TEST1 */
    Remove("TEST1");

    /* open TEST1 */
    if (Open("TEST1") == -1)
      Write("Cannot Open\n", 12, ConsoleOutput); /* should fail:
                                                    it was deleted */
    /* open the file */
    fId = Open("TEST2");

    if(fId == -1)
      Write("Cannot open TEST2\n", 18, ConsoleOutput);
        /* cannot open linked file */
    else
    {
      /* read 17 bytes from the file */
      Read(buf, 17, fId);

      /* write 17 bytes to the console */
      Write(buf, 17, ConsoleOutput);
        
      /* close the file */
      Close(fId);
    }

    /* Remove TEST2 */
    Remove("TEST2");
  }

  /* halt the machine */
  Halt();
}  
