/* userprog/testcase.cc

   This will contain the kernel-level code to test MP3.
*/

#include "system.h"
#include "machine.h"
#include "memmanager.h"

void MemManager::display(void) { 
  int i;

  printf ("\n\nPHYSICAL MEMORY DUMP:\n");

  for (i=0; i<NumPhysPages; i++) 
  {
    printf ("Physical Frame %d: ",i);
    if (coreFreeMap->Test(i)) 
      printf ("Used by program, virtual page %d\n", coreOwners[i]->virtualPage);
    else 
      printf ("Unused\n");
  }
  
  printf ("\n\nSWAP FILE DUMP:\n");
  for (i=0; i<NumSwapPages; i++)
    if (swapFreeMap->Test(i)) {
      printf ("%d: ",i);
      ASSERT(swapOwners[i]);
      printf ("Used by program, virtual page %d\n",
              swapOwners[i]->virtualPage);
    }

  printf ("\n\nTotal free pages: %d\n",memAvail());
  printf ("MemoryManager dump complete.\n");
}


void TestCase(int which_case) {
  unsigned int i;

  printf("\n\nOUTPUT FOR TESTCASE %d\n", which_case);
  switch (which_case) {
  case 0:
    // Display the state of main memory and swap file
    machine->memManager->display();
    break;

  case 1:
    // Dump the page table:
    printf ("\n\nPROGRAM PAGE TABLE CONTENTS:\n");
    for (i=0; i<currentThread->space->numPages; i++) {
      TranslationEntry *te=currentThread->space->pageTable+i;
      printf ("entry %d, phys %d, virt %d, %s, %s\n", i,
	te->physicalPage, te->virtualPage, te->legal?"legal":"illegal",
	te->valid?"valid":"invalid");
    }
    break;

  case 2:
    // Display the state of main memory and swap file
    // Dump the page table.
    machine->memManager->display();

    printf ("\n\nPROGRAM PAGE TABLE CONTENTS:\n");
    for (i=0; i<currentThread->space->numPages; i++) {
      TranslationEntry *te=currentThread->space->pageTable+i;
      printf ("entry %d, phys %d, virt %d, %s, %s\n", i,
	te->physicalPage, te->virtualPage, te->legal?"legal":"illegal",
	te->valid?"valid":"invalid");
    }
    break;

  default:
    printf ("Thread %8.8x (\"%s\") called for unimplemented test case %d\n",
	    (int)currentThread,currentThread->getName(),which_case);
  }
}
