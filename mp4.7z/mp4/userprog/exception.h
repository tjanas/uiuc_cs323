// exception.h            -*- C++ -*-
// From b-li's solution to MP2, modified by kwrohrer for MP3.
// No files besides exception.cc ought to #include this file!

#include "thread.h"
#include "console.h"
#include "system.h"
#include "synch.h"
#include "openfile.h"
 
static Console *console;
static Semaphore *readAvail;
static Semaphore *writeDone;

static void ReadAvail(int arg)
{
  if (arg) {} // ignore arg, silence warning.
  readAvail->V();
}

static void WriteDone(int arg)
{
  if (arg) {} // ignore arg, silence warning.
  writeDone->V();
}

#define MAX_OPENFILES  20

// The global file table for file management. It is assumed
// that a single process is executing in the system at a time.
// Thus we need to maintain only one global file table (there
// is no need for perprocess file tables). 
//
// Each entry in the file table points to an openfile object.
// The first entry is for ConsoleInput and the second entry 
// is for ConsoleOutput. (These two entries point to NULL).
// Indices into this file table serve as file handles
// (OpenfileIds).
static OpenFile *fileTable[MAX_OPENFILES];
