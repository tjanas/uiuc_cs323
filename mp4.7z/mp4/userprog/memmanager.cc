#include "memmanager.h"
#include "translate.h"
#include "machine.h"
#include "system.h"
#include "synch.h"
#include "syscall.h"


MemManager::MemManager()
{
    // WARNING: coreFreeMap (and like wise swapFreeMap) bits are CLEAR 
    // when free, not set when free; 
    coreFreeMap = new BitMap(NumPhysPages);  
    coreOwners = new TranslationEntry* [NumPhysPages];

    swapFreeMap = new BitMap(NumSwapPages);
    swapValidMap =new BitMap(NumSwapPages);
    swapOwners = new TranslationEntry* [NumSwapPages];

    int physFrame;
    for (physFrame=0; physFrame<NumPhysPages; physFrame++)
      coreOwners[physFrame] = (TranslationEntry*)NULL;

    int swapFrame;
    for (swapFrame=0; swapFrame<NumSwapPages; swapFrame++)
      swapOwners[swapFrame] = (TranslationEntry*)NULL;

    mutex=new Semaphore("mutex for memory manager data structures",1);

    fileSystem->Create("nachos.bs",0); 
    swapfile=fileSystem->Open("nachos.bs");
    ASSERT(swapfile!=NULL);                     // ...and open the swapfile
}

#include <errno.h>

//////////////////////////////////////////////////////////////////////
// Destructor: free all the resource used by MemManager
//////////////////////////////////////////////////////////////////////
MemManager::~MemManager()
{
    DEBUG('a',"MemManager destroyed with %d free pages\n",
	  memAvail());
    delete coreFreeMap;
    delete swapFreeMap;
    delete [] coreOwners;
    delete [] swapOwners;
    delete swapValidMap;
    delete swapfile;  //close it, then remove it:
    fileSystem->Remove("nachos.bs");
}


unsigned int MemManager::memAvail()
{
    return ( coreFreeMap->NumClear()+swapFreeMap->NumClear() );
}
 

void MemManager::clear(TranslationEntry *pageTable, int numPages)
{
  int swapFrame;
  int i;

  for (i = 0; i < numPages; i ++)
    if (pageTable[i].legal)
    {
      if (pageTable[i].valid) {
       // Free physical frames
        coreFreeMap->Clear(pageTable[i].physicalPage);
        coreOwners[pageTable[i].physicalPage] = (TranslationEntry *) NULL;
      } 
      // Free swap frames.
      swapFrame = swapSearch(&pageTable[i]);
      if (swapFrame != -1)
      {
	swapFreeMap->Clear(swapFrame);
	swapValidMap->Clear(swapFrame);
	swapOwners[swapFrame]=(TranslationEntry*)NULL;
      }
    }
}
 
//////////////////////////////////////////////////////////////////////
//  Finds a free frame in the main memory. See the definition above of 
//  a free frame.
//////////////////////////////////////////////////////////////////////
int MemManager::locateFirst()
{
    return coreFreeMap->Find();
}

//
//  Second chance algorithm
//
int MemManager::findFreeFrame() 
{
  static int physFrame=-1; // start from the top, work our way down.

  for (physFrame=(physFrame+1)%NumPhysPages;
       coreOwners[physFrame]->use;
       physFrame=(physFrame+1)%NumPhysPages)
    coreOwners[physFrame]->use=FALSE;

  DEBUG('v',"makeFreeFrame picking frame %d\n",physFrame);

  return physFrame;
}

/////////////////////////////////////////////////////////////////
// Reads in the appropriate page into the physFrame mentioned
/////////////////////////////////////////////////////////////////
void MemManager::pageIn(TranslationEntry *PTEntry, int physFrame)
{
  // printf("In pagein\n");
  // First check if the page is in the swap file. It will be found
  // if it was modified after being read from the source file. If
  // not in the swapfile then read it from the source file.
  int swapFrame = swapSearch(PTEntry);
  if (swapFrame != -1) 
  {
    // printf("Reading from the swap file\n");
    swapfile->ReadAt(&machine->mainMemory[physFrame*PageSize], PageSize,
		     swapFrame*PageSize);
  }
  else
  {
    // printf("Reading from the source file\n");
    currentThread->space->ReadSourcePage(&machine->mainMemory[physFrame*PageSize],
					 PTEntry->virtualPage);
  }

  PTEntry->physicalPage=physFrame;
  PTEntry->dirty = FALSE;
  PTEntry->valid = TRUE;
  PTEntry->use = TRUE;

  // Pagein changes corefree map and core owners. 
  coreFreeMap->Mark(physFrame);
  coreOwners[physFrame] = PTEntry;
}

//////////////////////////////////////////////////////////////////////
// MP3: Include your code here
// Find a free swap frame.  Set the ownership of this swap frame and
// write the "physFrame" to swap file.  Validate the swap frame and
// invalidate the virtual page.
//////////////////////////////////////////////////////////////////////
void MemManager::pageOut(int physFrame) 
{
  // printf("Pagingout %d\n", coreOwners[physFrame]->virtualPage);
 ASSERT(coreOwners[physFrame] != NULL);

 if (coreOwners[physFrame]->dirty) {
   coreOwners[physFrame]->dirty = FALSE;

   int swapFrame = swapSearch(coreOwners[physFrame]); 
   if (swapFrame == -1)
     swapFrame=swapFreeMap->Find();
   ASSERT(swapFrame >= 0);
   
   swapOwners[swapFrame]= coreOwners[physFrame];
   swapfile->WriteAt(&machine->mainMemory[physFrame*PageSize], PageSize,
		     swapFrame*PageSize);
   swapValidMap->Mark(swapFrame);
 }

 coreOwners[physFrame]->valid = FALSE;
 coreOwners[physFrame] = (TranslationEntry *) NULL;
 coreFreeMap->Clear(physFrame);
}


//
// Serve the page fault using pagein and pageout.
//
void MemManager::faultIn(TranslationEntry *PTEntry) 
{
  int physFrame = locateFirst();

  if(physFrame == -1) {
    physFrame = findFreeFrame();
    pageOut(physFrame);
  }

  pageIn(PTEntry, physFrame);
}


//////////////////////////////////////////////////////////////////////
// It would be easier if you implement a private method for searching
// a particular page table entry in "swapOwners".
//
// Also you may want to add a public method for handling page fault
// exceptions.
//
// Make appropriate changes into the header file so that your program
// does not have compilation problems
//////////////////////////////////////////////////////////////////////

void MemManager::PageFaultExceptionHandler(int BadVPage) 
{
  mutex->P();

  if (BadVPage >= machine->pageTableSize || machine->pageTable[BadVPage].legal == FALSE)
  {
    printf("Illegal memory access by thread : %s\n", currentThread->getName());
    printf("Halting the thread : %s\n", currentThread->getName());

    mutex->V();
    // call SC_Exit syscall exception
    machine->WriteRegister(2, SC_Exit);
    // The exit status
    machine->WriteRegister(4, 0);
    ExceptionHandler(SyscallException);
    // The current execution of this method will never get beyond this
    // position. The thread in whose context the method is executing is
    // halted. This is the reason why the mutex is released right here.
  }

  faultIn(machine->pageTable+BadVPage);
  mutex->V();
}


int MemManager::swapSearch(TranslationEntry *PTEntry) 
{
  for (int i=0; i<NumSwapPages; i++)
    if (swapOwners[i]==PTEntry) 
      return i;

  return -1;
}

