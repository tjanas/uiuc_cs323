/* syscalls.h 
 * 	Nachos system call interface.  These are Nachos kernel operations
 * 	that can be invoked from user programs, by trapping to the kernel
 *	via the "syscall" instruction.
 *
 *	This file is included by user programs and by the Nachos kernel. 
 *
 * Copyright (c) 1992-1993 The Regents of the University of California.
 * All rights reserved.  See copyright.h for copyright notice and limitation 
 * of liability and disclaimer of warranty provisions.
 */

#ifndef SYSCALLS_H
#define SYSCALLS_H

#include "copyright.h"

/* system call codes -- used by the stubs to tell the kernel which system call
 * is being asked for
 */

/* Syscalls for process management */
#define SC_Halt		0
#define SC_Exit		1
#define SC_Exec		2
#define SC_Join		3
#define SC_Fork		4
#define SC_Yield	5

/* Syscalls for the file system - MP4 */ 
#define SC_Create	6
#define SC_MkNode       7
#define SC_RmNode       8
#define SC_Remove       9
#define SC_Open		10
#define SC_Read		11
#define SC_Write	12
#define SC_Close	13
#define SC_Lseek        14

#define SC_TestCase     15
#define SC_Link         16

#ifndef IN_ASM

/* The system call interface.  These are the operations the Nachos
 * kernel needs to support, to be able to run user programs.
 *
 * Each of these is invoked by a user program by simply calling the 
 * procedure; an assembly language stub stuffs the system call code
 * into a register, and traps to the kernel.  The kernel procedures
 * are then invoked in the Nachos kernel, after appropriate error checking, 
 * from the system call entry point in exception.cc.
 */

/* Stop Nachos, and print out performance stats */
void Halt();		
 

/* Address space control operations: Exit, Exec, and Join */

/* This user program is done (status = 0 means exited normally). */
void Exit(int status);	

/* A unique identifier for an executing user program (address space) */
typedef int SpaceId;	
 
/* Run the executable, stored in the Nachos file "name", and return the 
 * address space identifier
 */
SpaceId Exec(char *name);
 
/* Only return once the the user program "id" has finished.  
 * Return the exit status.
 */
int Join(SpaceId id); 	
 

/* File system operations: Create, Open, Read, Write, Close
 * These functions are patterned after UNIX -- files represent
 * both files *and* hardware I/O devices.
 *
 * If this assignment is done before doing the file system assignment,
 * note that the Nachos file system has a stub implementation, which
 * will work for the purposes of testing out these routines.
 */
 
/* A unique identifier for an open Nachos file. */
typedef int OpenFileId;	

/* when an address space starts up, it has two open files, representing 
 * keyboard input and display output (in UNIX terms, stdin and stdout).
 * Read and Write can be used directly on these, without first opening
 * the console device.
 */

#define ConsoleInput	0  
#define ConsoleOutput	1  


/****************** To be implemented in MP4 ***************
 * Syscall: Link
 * Arguments: char *target Fully qualified path name of the new
 *                              directory entry.
 *            char *source Fully qualified path name of the current
 *                              file.
 * Return: int success Indicates whether the file was successfully
 *                     created (1) or not (-1)
 * Effect: Creates a hard link. That is a new directory entry (target)
 *         which points to the the inode pointed to by source. Should
 *         increment the usage count of the inode pointed to by source.
 ***********************************************************/ 
int Link(char *target, char *source);

/****************** To be implemented in MP4 ***************
 * Syscall: Create
 * Arguments: char *name Fully qualified path name of the file
 *                       to be created
 *            int fileSize Size of the file in bytes
 * Return: int success Indicates whether the file was successfully
 *                     created (1) or not (-1)
 * Effect: Creates a file on disk of the specified file name and
 *         size. If the disk does not have sufficient space 
 *         then a file of maximum possible size is created.
 *         Note that this system call does not return an
 *         OpenFileId i.e., it makes no changes to the global
 *         file table.
 ***********************************************************/ 
int Create(char *name, int fileSize);

/****************** To be implemented in MP4 ***************
 * Syscall: MkNode
 * Arguments: char *path Path name of the node (directory) to
 *                       be created
 * Return: int success Indicates whether the node(directory)
 *                     was successfully created (1) or not(-1)
 * Effect: Creates the specified directory. If the path is
 *         invalid, the call fails and returns -1. This call
 *         does not modify the global file table in any way.
 ***********************************************************/ 
int MkNode(char *path);

/****************** To be implemented in MP4 ***************
 * Syscall: RmNode
 * Arguments: char *path Path name of the node(directory) to 
 *                       be removed.
 * Return: int success Indicates whether the node(directory)
 *                     was successfully removed (1) or
 *                     not (-1)
 * Effect: Removes the specified directory only if it is
 *         empty. Returns -1 otherwise. This call does
 *         not modify the global file table in any way.
 ***********************************************************/ 
int RmNode(char *path);

/****************** To be implemented in MP4 ***************
 * Syscall: Remove
 * Arguments: char *file Fully qualified path name of the file
 *                       to be removed
 * Return: int success Indicates whether the file was 
 *                     successfully deleted(1) or not(-1)
 * Effect: Removes the specified file if it exists. Returns -1
 *         otherwise. This system call does not modify the
 *         global file table in any way.
 ***********************************************************/ 
int Remove(char *file);

/****************** To be implemented in MP4 ***************
 * Syscall: Open
 * Arguments: char *file Fully qualified pathname of the file
 *                       to be opened
 * Return: OpenFileId of OpenFileId that can be used to perform
 *                       read/write/close/lseek on the file
 * Effect: Creates an OpenFile object for the specified file
 *         and makes an entry for it in the global file table.
 *         Note that multiple calls to Open on the same file
 *         return distinct file handles. Note that the first 
 *         entry in the file table is reserved for ConsoleInput
 *         and the second for ConsoleOutput. These two entries
 *         should not be used for other files. 
 *         This call fails if the file does not exist or there
 *         are no free slots in the global file table.
 ***********************************************************/ 
OpenFileId Open(char *name);

/* Write "size" bytes from "buffer" to the open file. */
/****************** To be implemented in MP4 ***************
 * Syscall: Write
 * Arguments: char *buffer Buffer which is to be written into
 *                         the file at current seek position
 *            int size Number of bytes to write into the file
 *            OpenFileId id OpenFileId obtained from open
 * Return: int size Number of bytes actually written
 * Effect: The file should be open. The bytes are written into the
 *         file at the current seek position. The file size
 *         is automatically extended if necessary. Note that
 *         it may still not be possible to write all the bytes
 *         due to insufficient disk space. The call fails if
 *         the OpenFileId is invalid.
 ***********************************************************/ 
int Write(char *buffer, int size, OpenFileId id);

/****************** To be implemented in MP4 ***************
 * Syscall: Read
 * Arguments: char *buffer Buffer into which bytes are to be 
 *                         read from the file
 *            int size Number of bytes to read into the buffer
 *                     from the current seek position
 *            OpenFileId id OpenFileId obtained from open
 * Return: int size Number of bytes actually read 
 * Effect: The file should be open. The bytes are read from the
 *         file at the current seek position. The call fails if
 *         the OpenFileId is invalid.
 ***********************************************************/ 
int Read(char *buffer, int size, OpenFileId id);

/****************** To be implemented in MP4 ***************
 * Syscall: Close
 * Arguments: OpenFileId id OpenFileId of the file to be closed
 * Return: none
 * Effect: Removes the corresponding entry from the global file
 *         table.
 ***********************************************************/ 
void Close(OpenFileId id);

/****************** To be implemented in MP4 ***************
 * Syscall: Lseek
 * Arguments: OpenFileId id OpenFileId of the file whose 
 *                          pointer is to be modified
 *            int offset Offset from current position by which 
 *                       the file pointer is to be moved
 * Return: none
 * Effect: The seek position is limited by the file size.
 ***********************************************************/ 
void Lseek(OpenFileId id, int offset);

/* User-level thread operations: Fork and Yield.  To allow multiple
 * threads to run within a user program. 
 */

/* Fork a thread to run a procedure ("func") in the *same* address space 
 * as the current thread.
 */
void Fork(void (*func)());

/* Yield the CPU to another runnable thread, whether in this address space 
 * or not. 
 */
void Yield();		


/* Invoke kernel-level test case code (for MP3) */
void TestCase(int step);

#endif /* IN_ASM */

#endif /* SYSCALL_H */
