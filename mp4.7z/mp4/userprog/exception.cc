// exception.cc 
//  Entry point into the Nachos kernel from user programs.
//  There are two kinds of things that can cause control to
//  transfer back to here from user code:
//
//  syscall -- The user code explicitly requests to call a procedure
//  in the Nachos kernel.  Right now, the only function we support is
//  "Halt".
//
//  exceptions -- The user code does something that the CPU can't handle.
//  For instance, accessing memory that doesn't exist, arithmetic errors,
//  etc.  
//
//  Interrupts (which can also cause control to transfer from user
//  code into the Nachos kernel) are handled elsewhere.
//
// For now, this only handles the Halt() system call.
// Everything else core dumps.
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "system.h"
#include "syscall.h"

#include "machine.h"
#include "addrspace.h"
#include "exception.h"

static void updatePCReg(void);
static void initConsole(void);

int transfer(char *buffer, int addr,int size) {
  int oneChar;
  int i=0;
  
  while(!machine->ReadMem(addr, 1, &oneChar));
  
  while((size > i) && (oneChar != '\0'))      
    {  
      addr++;
      buffer[i] = oneChar;
      while(!machine->ReadMem(addr, 1, &oneChar));
      i++;
    }
  
  buffer[i] = 0;
  return i;
}
//----------------------------------------------------------------------
// ExceptionHandler
//  Entry point into the Nachos kernel.  Called when a user program
//  is executing, and either does a syscall, or generates an addressing
//  or arithmetic exception.
//
//
//  For system calls, the following is the calling convention:
//
//  system call code -- r2
//    arg1 -- r4
//    arg2 -- r5
//    arg3 -- r6
//    arg4 -- r7
//
//  The result of the system call, if any, must be put back into r2. 
//
// And don't forget to increment the pc before returning. (Or else you'll
// loop making the same system call forever!
//
//  "which" is the kind of exception.  The list of possible exceptions 
//  are in machine.h.
//----------------------------------------------------------------------

void
ExceptionHandler(ExceptionType which)
{
  int type = machine->ReadRegister(2);
  initConsole();

//-----------------------------------------------------------------------  
// Exception Handler handles system calls from a user program
// The following system calls have been implemented:
// 1.Halt()  halt the "NACHOS" system!!
// 2.Exit()  exit from the current user process, i.e kill it
// 3.Exec()  create a new process and execute it
// 4.Write() for writing text into a file
// 5.Read() for reading from a file
// 6.Join() for resuming after an Exec() call
//-----------------------------------------------------------------------

  if ((which == SyscallException) && (type == SC_Halt)) {
    DEBUG('a', "Shutdown, initiated by user program.\n");
    delete console;
    delete readAvail;
    delete writeDone;
    interrupt->Halt();
  } 

  else if((which == SyscallException) && (type == SC_Exit)) 
  {
      // not required for MP4
  }

  else if ((which == SyscallException) && (type == SC_Exec))
  {
      // not required for MP4
  }

  else if ((which == SyscallException) && (type == SC_Join))
  {  
      // not required for MP4
  }      
  else if((which == SyscallException) && (type == SC_Write))
  {
      int addr  = (int)machine->ReadRegister(4);  
      int Size = (int)machine->ReadRegister(5);
      OpenFileId writeHandle = (int)machine->ReadRegister(6);


      DEBUG('a', "Address of buffer %d\n", addr);
      DEBUG('a', "Size of buffer %d\n",Size );
      char buffer[Size+1];
      int oneChar, i=0;


      // Transfer buffer content from user space to kernel space
      while(!machine->ReadMem(addr, 1, &oneChar));

      while((i < Size) && (oneChar != '\0'))      
      {  
          addr++;
          buffer[i] = oneChar;
    while(!machine->ReadMem(addr, 1, &oneChar));
    i++;
      }

      buffer[i] = 0;
      Size = i;
      i = 0;
      
      if (writeHandle==ConsoleOutput) {     
          while (buffer[i] != 0 && i < Size) 
          {      
              // wait for write process to be done
        console->PutChar(buffer[i++]);
              writeDone->P();
          }
      } else {
          OpenFile *fp=fileTable[writeHandle];
    if (fp==NULL) 
      machine->WriteRegister(2, -1);
    else 
      machine->WriteRegister(2, fp->Write(buffer, Size));
      }

      updatePCReg();
  }
  else if((which == SyscallException) && (type == SC_Create))
  {
      // To be implemented in MP4
    int filename  = (int)machine->ReadRegister(4);
    int size = (int)machine->ReadRegister(5);

    char *name=new char[100];

    transfer(name, filename, 100);

    //printf("create ex %s\n", name);
    if (fileSystem->Create(name, size))            
      machine->WriteRegister(2, 1);
    else
      machine->WriteRegister(2, -1);

    updatePCReg();
  } 
  else if((which == SyscallException) && (type == SC_MkNode))
  {
      // To be implemented in MP4
    int filename  = (int)machine->ReadRegister(4);
    
    char *name=new char[100];

    transfer(name, filename, 100);


    if (fileSystem->MkNode(name))
      machine->WriteRegister(2, 1);
    else
      machine->WriteRegister(2, -1);
    //printf("mk done\n"); 
    updatePCReg();

  } 
  else if((which == SyscallException) && (type == SC_RmNode))
  {    
       // To be implemented in MP4
    int filename  = (int)machine->ReadRegister(4);

    char *name=new char[100];


    transfer(name, filename, 100);
    if (fileSystem->RmNode(name))

      machine->WriteRegister(2, 1);
    else
      machine->WriteRegister(2, -1);
    updatePCReg();
      
  } 
  else if((which == SyscallException) && (type == SC_Remove))
  {
    // To be implemented in MP4
    int filename  = (int)machine->ReadRegister(4);

    char *name=new char[100];

    transfer(name, filename, 100);

    if (fileSystem->Remove(name))
      machine->WriteRegister(2,1);
    else
      machine->WriteRegister(2,-1);

    updatePCReg();
  } 
  else if((which == SyscallException) && (type == SC_Open))
  {
    // To be implemented in MP4
    int openID=-1;
    int filename  = (int)machine->ReadRegister(4);
    char *name=new char[100];

    transfer(name, filename, 100);
    
    //printf("open %s\n", name);
    OpenFile * fp=fileSystem->Open(name);
    if (fp!=NULL) {
      for (int i=2; i < MAX_OPENFILES; i++) {
  if (fileTable[i]==NULL) {
    fileTable[i]=fp;
    openID=i;
    break;
  }
      }
    }
    
    machine->WriteRegister(2, openID);
    updatePCReg();
  } 
  else if((which == SyscallException) && (type == SC_Read))
  {    
    // To be implemented in MP4
    int buffer = (int)machine->ReadRegister(4);
    //printf("read to %d\n", buffer);
    int size=(int)machine->ReadRegister(5);
    OpenFileId id=(int)machine->ReadRegister(6);
    char *data=new char[size];
    int result;
    

    OpenFile *fp=fileTable[id];
    
    if (fp==NULL)
      result=-1;
    else {
      
      result=fp->Read(data, size);
      // printf("read %s\n", data);
      for (int i=0; i <size; i++) {
  while(!machine->WriteMem(buffer+i,1 , data[i]));
    
      }
      
    }
    
    machine->WriteRegister(2, result);
    
    updatePCReg();
    
  } 
  else if((which == SyscallException) && (type == SC_Close))
  {
      // To be implemented in MP4
    int openID = (int) machine->ReadRegister(4);
    

    if (openID > 0 && openID < MAX_OPENFILES) {
    
      delete fileTable[openID];
      fileTable[openID]=NULL;
    }

    updatePCReg();
    
  } 
  else if((which == SyscallException) && (type == SC_Lseek))
  {
      // To be implemented in MP4


    OpenFileId id=(int)machine->ReadRegister(4);
    int offset=(int)machine->ReadRegister(5);
    OpenFile *fp=fileTable[id];

    fp->Seek(offset+fp->seekPosition);
    updatePCReg();
  } 
  else if((which == SyscallException) && (type == SC_TestCase)) {
    updatePCReg();
    TestCase(machine->ReadRegister(4)); 
  }
  else if((which == SyscallException) && (type == SC_Link))
  {
    // To be implemented in MP4
    int p_target  = (int)machine->ReadRegister(4);
    int p_source = (int)machine->ReadRegister(5);

    char *target=new char[100];
    char *source=new char[100];

    transfer(target, p_target, 100);
    transfer(source, p_source, 100);

    // printf("link %s -> %s\n", target, source);
    
    if (fileSystem->Link(target, source))            
      machine->WriteRegister(2, 1);
    else
      machine->WriteRegister(2, -1);

    updatePCReg();
    
  }
  else if (which == PageFaultException) 
  {
    stats->numPageFaults++;
    int BadVPage=(machine->ReadRegister(BadVAddrReg)/PageSize);
    
    machine->memManager->PageFaultExceptionHandler(BadVPage);
  }
} 


//-----------------------------------------------------------------
// Updating the Program Counter before returning to the User mode
// ensures that the "SYSCALL" instruction is not executed forever.
// Don't use this for page faults, because you want to retry the
// faulting instruction, not skip it!
//-----------------------------------------------------------------

void updatePCReg(void)
{
  int pc = machine->ReadRegister(PCReg);
  machine->WriteRegister(PrevPCReg,pc);
  pc = machine->ReadRegister(NextPCReg);
  machine->WriteRegister(PCReg,pc);
  pc += 4;
  machine->WriteRegister(NextPCReg,pc);
}

// This initialization should only be done once.
void initConsole(void)
{
  static int Initialized = 0;
  
  if (Initialized == 0) {
      Initialized = 1; 
      readAvail = new Semaphore("readAvail", 0);
      writeDone = new Semaphore("writeDone", 0);
      console = new Console((char *) NULL, (char *) NULL,
          ReadAvail, WriteDone, 0);
  }
}


