// openfile.h 
//  Data structures for opening, closing, reading and writing to 
//  individual files.  The operations supported are similar to
//  the UNIX ones -- type 'man open' to the UNIX prompt.
//
//  In this baseline implementation of the file system, we don't 
//  worry about concurrent accesses to the file system
//  by different threads.
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.
//
// Modified by Terrence B. Janas (tjanas@uiuc.edu)
// University of Illinois at Urbana-Champaign
// Course: CS 323
// April 24, 2003

#ifndef OPENFILE_H
#define OPENFILE_H

#include "copyright.h"
#include "utility.h"

// this is the data structure used by the Stat function to communicate
// information about an open file
struct FileStat
{
  bool directory;            // true if this is a directory; false otherwise
  int length;                // length of the file in bytes
  unsigned int lastmodified; // number of seconds since the Unix epoch began
};

// forward declare FileHeader
class FileHeader;

class OpenFile {
  public:
    OpenFile(int sector);   // Open a file whose header is located
                            // at "sector" on the disk
    ~OpenFile();      // Close the file

    void Seek(int position);   // Set the position from which to 
                               // start reading/writing -- UNIX lseek

    int Read(char *into, int numBytes); // Read/write bytes from the file,
                                        // starting at the implicit position.
                                        // Return the # actually read/written,
                                        // and increment position in file.
    int Write(char *from, int numBytes);

    int ReadAt(char *into, int numBytes, int position);
              // Read/write bytes from the file,
              // bypassing the implicit position.
    int WriteAt(char *from, int numBytes, int position);

    int Length();     // Return the number of bytes in the
                      // file (this interface is simpler 
                      // than the UNIX idiom -- lseek to 
                      // end of file, tell, lseek back 
    bool Stat(FileStat *stat); // retrieve statistics about the file
    
    int seekPosition;     // Current position within the file  
    FileHeader *hdr;      // Header for this file 
};

#endif // OPENFILE_H
