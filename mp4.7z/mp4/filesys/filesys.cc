// filesys.cc 
//  Routines to manage the overall operation of the file system.
//  Implements routines to map from textual file names to files.
//
//  Each file in the file system has:
//     A file header, stored in a sector on disk 
//    (the size of the file header data structure is arranged
//    to be precisely the size of 1 disk sector)
//     A number of data blocks
//     An entry in the file system directory
//
//  The file system consists of several data structures:
//     A bitmap of free disk sectors (cf. bitmap.h)
//     A directory of file names and file headers
//
//      Both the bitmap and the directory are represented as normal
//  files.  Their file headers are located in specific sectors
//  (sector 0 and sector 1), so that the file system can find them 
//  on bootup.
//
//  The file system assumes that the bitmap and directory files are
//  kept "open" continuously while Nachos is running.
//
//  For those operations (such as Create, Remove) that modify the
//  directory and/or bitmap, if the operation succeeds, the changes
//  are written immediately back to disk (the two files are kept
//  open during all this time).  If the operation fails, and we have
//  modified part of the directory and/or bitmap, we simply discard
//  the changed version, without writing it back to disk.
//
//  Our implementation at this point has the following restrictions:
//
//     there is no synchronization for concurrent accesses
//     files have a fixed size, set when the file is created
//     files cannot be bigger than about 3KB in size
//     there is no hierarchical directory structure, and only a limited
//       number of files can be added to the system
//     there is no attempt to make the system robust to failures
//      (if Nachos exits in the middle of an operation that modifies
//      the file system, it may corrupt the disk)
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.
//
// Modified by Terrence B. Janas (tjanas@uiuc.edu)
// University of Illinois at Urbana-Champaign
// Course: CS 323
// April 24, 2003

#include <string.h>
#include "copyright.h"

#include "disk.h"
#include "bitmap.h"
#include "directory.h"
#include "filehdr.h"
#include "filesys.h"

// Sectors containing the file headers for the bitmap of free sectors,
// and the directory of files.  These file headers are placed in well-known 
// sectors, so that they can be located on boot-up.
#define FreeMapSector     0
#define RootDirSector     1

// Initial file sizes for the bitmap and directory; until the file system
// supports extensible files and directories, the number of files in the
// root directory is limited to 10
#define FreeMapFileSize   (NumSectors / BitsInByte)
#define NumRootDirEntries 10
#define RootDirFileSize   (sizeof(DirectoryEntry) * NumRootDirEntries)

//----------------------------------------------------------------------
// FileSystem::FileSystem
//  Initialize the file system.  If format = TRUE, the disk has
//  nothing on it, and we need to initialize the disk to contain
//  an empty directory, and a bitmap of free sectors (with almost but
//  not all of the sectors marked as free).  
//
//  If format = FALSE, we just have to open the files
//  representing the bitmap and the directory.
//
//  "format" -- should we initialize the disk?
//----------------------------------------------------------------------

FileSystem::FileSystem(bool format)
{ 
  //DebugInit("q");
  DEBUG('f', "Initializing the file system.\n");

  if (format)
  {
    // place a new file system on the disk

    BitMap *freeMap = new BitMap(NumSectors);
    Directory *rootDir = new Directory(NumRootDirEntries);

    FileHeader *mapHdr = new FileHeader;
    FileHeader *rootHdr = new FileHeader;

    DEBUG('f', "Formatting the file system.\n");

    // First, allocate space for FileHeaders for the directory and bitmap
    // (make sure no one else grabs these!)
    freeMap->Mark(FreeMapSector);     
    freeMap->Mark(RootDirSector);

    // Second, allocate space for the data blocks containing the contents
    // of the directory and bitmap files.  There better be enough space!

    bool success = mapHdr->Allocate(freeMap, FreeMapFileSize);
    ASSERT(success);
    success = rootHdr->Allocate(freeMap, RootDirFileSize);
    ASSERT(success);

    // Flush the bitmap and directory FileHeaders back to disk
    // We need to do this before we can "Open" the file, since open
    // reads the file header off of disk (and currently the disk has garbage
    // on it!).

    DEBUG('f', "Writing headers back to disk.\n");
    mapHdr->WriteBack(FreeMapSector);    
    rootHdr->WriteBack(RootDirSector);

    // OK to open the bitmap and directory files now
    // The file system operations assume these two files are left open
    // while Nachos is running.

    freeMapFile = new OpenFile(FreeMapSector);
    rootDirFile = new OpenFile(RootDirSector);
     
    // Once we have the files "open", we can write the initial version
    // of each file back to disk.  The directory at this point is completely
    // empty; but the bitmap has been changed to reflect the fact that
    // sectors on the disk have been allocated for the file headers and
    // to hold the file data for the directory and bitmap.

    DEBUG('f', "Writing bitmap and directory back to disk.\n");
    freeMap->WriteBack(freeMapFile);   // flush changes to disk
    rootDir->WriteBack(rootDirFile);

    if (DebugIsEnabled('f'))
    {
      freeMap->Print();
      rootDir->Print();
    }

    delete freeMap; 
    delete rootDir; 
    delete mapHdr; 
    delete rootHdr;
  }
  else
  {
    // if we are not formatting the disk, just open the files representing
    // the bitmap and directory; these are left open while Nachos is running
    freeMapFile = new OpenFile(FreeMapSector);
    rootDirFile = new OpenFile(RootDirSector);
  } // end else - if (format)
}

//----------------------------------------------------------------------
// FileSystem::Create
//  Create a file in the Nachos file system (similar to UNIX create).
//  Since we can't increase the size of files dynamically, we have
//  to give Create the initial size of the file.
//
//  The steps to create a file are:
//      Make sure a file or directory with the same name doesn't already exist
//      Allocate a sector for the file header
//      Allocate space on disk for the data blocks for the file
//      Add the name to the parent directory
//      Store the new file header on disk 
//      Flush the changes to the bitmap and the directory back to disk
//
//  Return TRUE if everything goes ok, otherwise, return FALSE.
//
//  Create fails if:
//      name is already a file or directory in parent directory
//      no free space for file header
//      no free entry for file in directory
//      no free space for data blocks for the file 
//
//  Note that this implementation assumes there is no concurrent access
//  to the file system!
//
//  "name" -- name of file to be created
//  "initialSize" -- size of file to be created
//----------------------------------------------------------------------

bool
FileSystem::Create(char *name, int initialSize)
{
  Directory *directory;
  BitMap *freeMap;
  FileHeader *hdr = new FileHeader;
  FileHeader *newhdr;
  int sector;
  bool success;
  bool flag = FALSE;
  OpenFile* directory_file;  // MP4
  char* thisDir;             // MP4
  char* nextDir;             // MP4

  DEBUG('f', "Creating file %s, size %d\n", name, initialSize);

  // load the root directory
  directory = new Directory(NumRootDirEntries);
  directory->FetchFrom(rootDirFile);
  directory_file = rootDirFile;
  directory_file->hdr->is_a_directory = TRUE;

  DEBUG('q', "create(): root dir table loaded, time to traverse...\n");

  /***** DIRECTORY TRAVERSAL CODE *****/
  thisDir = strtok(name,"/");  // get first directory name in the path
  nextDir = strtok(NULL,"/");  // get next directory name in the path
  while( nextDir != NULL )   // as long as this directory is not the end...
  {
    sector = directory->Find(thisDir);  // Look for the entry...
    if (sector == -1)
    {
      delete directory;  // thisDir does not exist, cannot traverse further
      delete hdr;
      DEBUG('q', "create(): cannot traverse, dir doesn't exist\n");
      return FALSE;      // failure to create a file
    }

    hdr->FetchFrom(sector);        // ...and verify it is a directory
    if (hdr->is_a_directory != TRUE)
    {
      delete directory;  // thisDir is NOT a directory!
      delete hdr;
      DEBUG('q', "create(): invaild path (dir is a file), cannot traverse\n");
      return FALSE;    // failure to create a file
    }

    if (flag)
      delete directory_file;

    directory_file = new OpenFile(sector);
    flag = TRUE;
    directory->FetchFrom(directory_file);
    strcpy(thisDir,nextDir);
    nextDir = strtok(NULL,"/");
    DEBUG('q', "create(): just finished a single traversal loop...\n");
  }
  /***** END DIRECTORY TRAVERSAL CODE *****/
  DEBUG('q', "create(): traversal complete!\n");


  // look for file
  if (directory->Find(thisDir) != -1) {
    success = FALSE;      // file is already in directory
    DEBUG('q', "create(): file already exists, cannot create\n");
  }
  else
  {
    // load the free block bitmap
    freeMap = new BitMap(NumSectors);
    freeMap->FetchFrom(freeMapFile);
    
    sector = freeMap->Find(); // find a sector to hold the file header
    if (sector == -1) {
      success = FALSE;    // no free block for file header
      DEBUG('q', "create(): failed, no free block for file header\n");
    }
    else if (!directory->Add(thisDir, sector)) {
      success = FALSE;  // no space in directory
      DEBUG('q', "create(): failed, no free dir entry for file\n");
    }
    else
    {
      newhdr = new FileHeader;
      newhdr->is_a_directory = FALSE;
      newhdr->numLinks = 1;
      if (!newhdr->Allocate(freeMap, initialSize)) {
        success = FALSE;  // no space on disk for data
        DEBUG('q', "create(): failed, no space on disk for data\n");
      }
      else
      {
        success = TRUE;
        // everthing worked, flush all changes back to disk
        DEBUG('q', "create(): worked, now update the changes to disk...\n");
        newhdr->WriteBack(sector);
        directory->WriteBack(directory_file);
        freeMap->WriteBack(freeMapFile);
        DEBUG('q', "create(): changes have been written to disk\n");
      }
      
      delete newhdr;
    }
    
    delete freeMap;
  }
  
  delete directory;
  delete hdr;
  if (flag)
    delete directory_file;
  DEBUG('q', "create(): exiting function\n");
  return success;
}

//----------------------------------------------------------------------
// FileSystem::MkNode
//  Create a directory in the Nachos file system
//
//  The steps to create a directory are:
//      Make sure a file or directory with the same name doesn't already exist
//      Allocate a sector for the directory header
//      Allocate space on disk for the data blocks for the directory table
//      Add the name to the parent directory
//      Store the new directory header on disk 
//      Flush the changes to the bitmap and the tables of both directories
//          (parent and new) back to disk
//
//  Return TRUE if everything goes ok, otherwise, return FALSE.
//
//  Create fails if:
//      name is already a file or directory in parent directory
//      no free space for directory header
//      no free entry for directory in parent directory
//      no free space for data blocks for the file 
//
//  You may assume there is no concurrent access to the filesystem.
//
//  "name" -- name of file to be created
//----------------------------------------------------------------------

bool
FileSystem::MkNode(char *name)
{
  DEBUG('f', "Creating directory %s\n", name);
  // must implement for MP4
  int sectorNum;
  char* thisDir;
  char* nextDir;
  FileHeader* filehdr = new FileHeader;
  FileHeader* directory_inode;
  Directory* rootDir;
  Directory* directory_table;
  BitMap* freelist;
  OpenFile* directory_file;
  bool flag = FALSE;

  // Load the root directory table
  rootDir = new Directory(NumRootDirEntries);
  rootDir->FetchFrom(rootDirFile);  // initialize rootDir contents from disk
  directory_file = rootDirFile;
  directory_file->hdr->is_a_directory = TRUE;

  DEBUG('q', "mknode(): root dir table loaded, time to traverse...\n");

  /***** DIRECTORY TRAVERSAL CODE *****/

  thisDir = strtok(name,"/");  // get first directory name in the path
  nextDir = strtok(NULL,"/");  // get next directory name in the path

  while( nextDir != NULL )   // as long as this directory is not the end...
  {
    sectorNum = rootDir->Find(thisDir);  // Look for the entry...
    if (sectorNum == -1)
    {
      delete rootDir;  // thisDir does not exist, cannot traverse further
      delete filehdr;
      DEBUG('q', "mknode(): failure, dir in the path does not exist!\n");
      return FALSE;    // failure to create a directory
    }

    filehdr->FetchFrom(sectorNum);        // ...and verify it is a directory
    if (filehdr->is_a_directory != TRUE)
    {
      delete rootDir;  // thisDir is NOT a directory!
      delete filehdr;
      DEBUG('q', "mknode(): failure, dir in the path is actually a file!\n");
      return FALSE;    // failure to create a directory
    }

    if (flag)
      delete directory_file;

    directory_file = new OpenFile(sectorNum);
    flag = TRUE;
    rootDir->FetchFrom(directory_file);
    strcpy(thisDir,nextDir);
    nextDir = strtok(NULL,"/");
  }

  /***** END DIRECTORY TRAVERSAL CODE *****/
  DEBUG('q', "mknode(): traversal complete!\n");


  // verify that the directory at the end of the traversal doesn't exist
  if ( rootDir->Find(thisDir) != -1 )
  {
    delete rootDir;         // the directory already exists
    delete filehdr;
    if (flag) {
      delete directory_file;
    }
    DEBUG('q', "mknode(): sorry, file/dir name already exists!\n");
    return FALSE;
  }

  DEBUG('q', "mknode(): passed uniqueness test\n");


  // Load the bit map of free disk blocks
  freelist = new BitMap(NumSectors);
  freelist->FetchFrom(freeMapFile);

  DEBUG('q', "mknode(): bit map of free blocks loaded from disk\n");

  // Find a free block to use as new directory inode
  sectorNum = freelist->Find();

  // Were we able to find a free block for the directory inode?
  if (sectorNum == -1)
  {
    delete rootDir;         // no free blocks left,
    delete filehdr;
    if (flag) {
      delete directory_file;  // cannot create the directory inode
    }
    delete freelist;
    return FALSE;
  }

  DEBUG('q', "mknode(): free block for directory inode found\n");


  // Create a directory entry for the directory we are about to create
  if (rootDir->Add(thisDir,sectorNum) == FALSE)
  {
    delete rootDir;         // no free directory entries left,
    delete filehdr;
    if (flag) {
      delete directory_file;  // cannot create the directory
    }
    delete freelist;
    return FALSE;
  }

  DEBUG('q', "mknode(): dir entry successfully entered into parent dir\n");


  // allocate disk blocks for the directory table
  directory_inode = new FileHeader;
  if (directory_inode->Allocate(freelist,RootDirFileSize) == FALSE)
  {
    delete rootDir;         // not enough space,
    delete filehdr;
    if (flag)
      delete directory_file;  // cannot create the directory
    delete freelist;
    delete directory_inode;
    return FALSE;
  }
  DEBUG('q', "mknode(): disk blocks for new directory table allocated OK\n");



  // write the inode of the new directory to disk
  directory_inode->is_a_directory = TRUE;
  directory_inode->numLinks = 1;
  directory_inode->WriteBack(sectorNum);
  DEBUG('q', "mknode(): WriteBack of inode of new directory OK\n");


  // create a new directory table, and write it to disk
  directory_table = new Directory(NumRootDirEntries);
  OpenFile* emptyDirFile = new OpenFile(sectorNum);
  directory_table->WriteBack(emptyDirFile);
  DEBUG('q', "mknode(): WriteBack of new directory table OK\n");



  // write the modified directory table to disk (parent of new dir)
  rootDir->WriteBack(directory_file);
  DEBUG('q', "mknode(): WriteBack of parent directory (rootDir) OK\n");



  // write the modified map of free blocks to disk
  freelist->WriteBack(freeMapFile);
  DEBUG('q', "mknode(): WriteBack of free map OK\n");


  delete rootDir;           // cleanup time
  delete filehdr;
  if (flag)
    delete directory_file;
  delete directory_table;
  delete freelist;
  delete directory_inode;
  delete emptyDirFile;


  DEBUG('q', "mknode(): successful, returning TRUE\n");

  return TRUE;
}

//----------------------------------------------------------------------
// FileSystem::Open
//  Open a file for reading and writing.  
//  To open a file:
//    Find the location of the file's header, using the directory 
//    Bring the header into memory
//
//  "name" -- the text name of the file to be opened
//----------------------------------------------------------------------

OpenFile *
FileSystem::Open(char *name)
{ 
  Directory *directory;
  OpenFile *openFile = NULL;
  int sector;

  char* thisDir;                    // MP4
  char* nextDir;                    // MP4
  FileHeader *hdr = new FileHeader; // MP4
  OpenFile* directory_file;         // MP4
  bool flag = FALSE;                // MP4


  DEBUG('f', "Opening file %s\n", name);

  // load the root directory
  directory = new Directory(NumRootDirEntries);
  directory->FetchFrom(rootDirFile);
  directory_file = rootDirFile;

  DEBUG('q', "open(): root dir table loaded, time to traverse...\n");

  /***** DIRECTORY TRAVERSAL CODE *****/
  thisDir = strtok(name,"/");  // get first directory name in the path
  nextDir = strtok(NULL,"/");  // get next directory name in the path
  while( nextDir != NULL )   // as long as this directory is not the end...
  {
    sector = directory->Find(thisDir);  // Look for the entry...
    if (sector == -1)
    {
      delete directory;  // thisDir does not exist, cannot traverse further
      delete hdr;
      DEBUG('q', "open(): cannot traverse, dir doesn't exist\n");
      return NULL;      // failure to open a file
    }

    hdr->FetchFrom(sector);        // ...and verify it is a directory
    if (hdr->is_a_directory != TRUE)
    {
      delete directory;  // thisDir is NOT a directory!
      delete hdr;
      DEBUG('q', "open(): invaild path (dir is a file), cannot traverse\n");
      return NULL;    // failure to open a file
    }

    if (flag)
      delete directory_file;

    directory_file = new OpenFile(sector);
    flag = TRUE;
    directory->FetchFrom(directory_file);
    strcpy(thisDir,nextDir);
    nextDir = strtok(NULL,"/");
    DEBUG('q', "open(): just finished a single traversal loop...\n");
  }
  /***** END DIRECTORY TRAVERSAL CODE *****/
  DEBUG('q', "open(): traversal complete!\n");

  
  // look for file
  sector = directory->Find(thisDir);
  if (sector >= 0)
    openFile = new OpenFile(sector);  // name was found in directory 

  delete directory;
  delete hdr;
  if (flag)
    delete directory_file;
  return openFile;        // return NULL if not found
}

//----------------------------------------------------------------------
// FileSystem::Remove
//  Delete a file from the file system.  This requires:
//      Remove it from the directory
//      Delete the space for its header
//      Delete the space for its data blocks
//      Write changes to directory, bitmap back to disk
//
//  Return TRUE if the file was deleted, FALSE if the file wasn't
//  in the file system.
//
//  THIS FUNCTION SHOULD NOT REMOVE DIRECTORIES!
//
//  "name" -- the text name of the file to be removed
//----------------------------------------------------------------------

bool
FileSystem::Remove(char *name)
{ 
  DEBUG('f', "Deleting file %s\n", name);

  Directory *directory;
  BitMap *freeMap;
  FileHeader *fileHdr;
  int sector;
  OpenFile* directory_file;  // MP4
  char* thisDir;             // MP4
  char* nextDir;             // MP4
  bool flag = FALSE;         // MP4
  FileHeader *hdr = new FileHeader;  // MP4


  // load the root directory table
  directory = new Directory(NumRootDirEntries);
  directory->FetchFrom(rootDirFile);
  directory_file = rootDirFile;


  DEBUG('q', "remove(): root dir table loaded, time to traverse...\n");

  /***** DIRECTORY TRAVERSAL CODE *****/
  thisDir = strtok(name,"/");  // get first directory name in the path
  nextDir = strtok(NULL,"/");  // get next directory name in the path
  while( nextDir != NULL )   // as long as this directory is not the end...
  {
    sector = directory->Find(thisDir);  // Look for the entry...
    if (sector == -1) {
      delete directory;  // thisDir does not exist, cannot traverse further
      delete hdr;
      DEBUG('q', "remove(): cannot traverse, dir doesn't exist\n");
      return FALSE;      // failure to remove a file
    }

    hdr->FetchFrom(sector);        // ...and verify it is a directory
    if (hdr->is_a_directory != TRUE)
    {
      delete directory;  // thisDir is NOT a directory!
      delete hdr;
      DEBUG('q', "remove(): invaild path (dir is a file), cannot traverse\n");
      return FALSE;    // failure to remove a file
    }

    if (flag)  // does directory_file point to an object WE allocated?
      delete directory_file;

    directory_file = new OpenFile(sector);
    flag = TRUE;
    directory->FetchFrom(directory_file);
    strcpy(thisDir,nextDir);
    nextDir = strtok(NULL,"/");
    DEBUG('q', "remove(): just finished a single traversal loop...\n");
  }
  /***** END DIRECTORY TRAVERSAL CODE *****/

  DEBUG('q', "remove(): traversal complete!\n");

  sector = directory->Find(thisDir);
  if (sector == -1)
  {
    delete directory;
    delete hdr;
    if (flag)
      delete directory_file;
    DEBUG('q', "remove(): file doesn't exist, can't remove\n");
    return FALSE;       // file not found 
  }


  
  // load the file header
  fileHdr = new FileHeader;
  fileHdr->FetchFrom(sector);

  if (fileHdr->is_a_directory == TRUE)
  {
      delete directory;  // thisDir is NOT a directory!
      delete hdr;
      delete fileHdr;
      if (flag)
        delete directory_file;
      DEBUG('q', "remove(): doh! trying to remove a directory, failure\n");
      return FALSE;    // failure to remove a file
  }


  // link() compatibility code
  fileHdr->numLinks = fileHdr->numLinks - 1;
  if (fileHdr->numLinks == 0)
  {
    // original remove() code, before we supported hard links

    // load the free sector bitmap
    freeMap = new BitMap(NumSectors);
    freeMap->FetchFrom(freeMapFile);

    fileHdr->Deallocate(freeMap);     // remove data blocks
    freeMap->Clear(sector);     // remove header block

    directory->Remove(thisDir);    // remove the directory entry
    freeMap->WriteBack(freeMapFile);    // flush to disk
    directory->WriteBack(directory_file);   // flush to disk

    delete fileHdr;
    delete directory;
    delete freeMap;
    delete hdr;
    if (flag)
      delete directory_file;
    DEBUG('q', "remove(): success, exiting function...\n");
    return TRUE;
  }
  else    // we cannot blow away the inode
  {
    DEBUG('q', "remove(): other links exist, only dir entry is removed\n");
    fileHdr->WriteBack(sector);  // writeback the inode
    directory->Remove(thisDir);  // remove the directory entry
    directory->WriteBack(directory_file);  // and writeback to disk

    delete fileHdr;
    delete directory;
    delete hdr;
    if (flag)
      delete directory_file;
    DEBUG('q', "remove(): success, exiting function...\n");
    return TRUE;
  }
} 

//----------------------------------------------------------------------
// FileSystem::RmNode
//  Delete a directory from the file system.  This requires:
//      Remove it from the directory
//      Delete the space for its header
//      Delete the space for its data blocks
//      Write changes to directory, bitmap back to disk
//
//  Return TRUE if the file was deleted, FALSE if the file wasn't
//  in the file system.
//
//  THIS FUNCTION SHOULD ONLY REMOVE EMPTY DIRECTORIES!
//
//  "name" -- the text name of the file to be removed
//----------------------------------------------------------------------

bool
FileSystem::RmNode(char *name)
{ 
  DEBUG('f', "Deleting directory %s\n", name);

  // implement for MP4
  int sectorNum;
  char *thisDir;
  char *nextDir;
  FileHeader* filehdr = new FileHeader;
  Directory* rootDir;
  Directory* dirToRemove;
  BitMap* freelist;
  OpenFile* directory_file;
  OpenFile* dirToRemove_file;
  bool flag = FALSE;

  // Load the root directory table
  rootDir = new Directory(NumRootDirEntries);
  rootDir->FetchFrom(rootDirFile);  // initialize rootDir contents from disk
  directory_file = rootDirFile;

  DEBUG('q', "rmnode(): root dir table loaded, time to traverse...\n");

  /***** DIRECTORY TRAVERSAL CODE *****/
  thisDir = strtok(name,"/");  // get first directory name in the path
  nextDir = strtok(NULL,"/");  // get next directory name in the path
  while( nextDir != NULL )   // as long as this directory is not the end...
  {
    sectorNum = rootDir->Find(thisDir);  // Look for the entry...
    if (sectorNum == -1)
    {
      delete rootDir;  // thisDir does not exist, cannot traverse further
      delete filehdr;
      DEBUG('q', "rmnode(): failure, dir in the path does not exist!\n");
      return FALSE;    // failure to remove a directory
    }

    filehdr->FetchFrom(sectorNum);        // ...and verify it is a directory
    if (filehdr->is_a_directory != TRUE)
    {
      delete rootDir;  // thisDir is NOT a directory!
      delete filehdr;
      DEBUG('q', "rmnode(): failure, dir in the path is actually a file!\n");
      return FALSE;    // failure to remove a directory
    }

    if (flag)
      delete directory_file;

    directory_file = new OpenFile(sectorNum);
    flag = TRUE;
    rootDir->FetchFrom(directory_file);
    strcpy(thisDir,nextDir);
    nextDir = strtok(NULL,"/");
  }
  /***** END DIRECTORY TRAVERSAL CODE *****/
  DEBUG('q', "rmnode(): traversal complete!\n");

  // verify that the directory at the end of the traversal exists
  sectorNum = rootDir->Find(thisDir);
  if ( sectorNum == -1 )
  {
    delete rootDir;         // the directory doesn't exists
    delete filehdr;
    if (flag)
      delete directory_file;
    DEBUG('q', "rmnode(): sorry, file/dir name doesn't exist!\n");
    return FALSE;
  }
  DEBUG('q', "rmnode(): passed existance test\n");

  dirToRemove = new Directory(NumRootDirEntries);
  dirToRemove_file = new OpenFile(sectorNum);
  dirToRemove->FetchFrom(dirToRemove_file);
  filehdr->FetchFrom(sectorNum);  // added for link() compatibility

  // RmNode should fail if it tries to remove a non-empty directory.
  // Here I am making an assumption that this should hold, even if this is
  // actually just a link to a directory
  if (dirToRemove->isEmpty() == FALSE)
  {
    delete rootDir;
    delete filehdr;
    if (flag)
      delete directory_file;
    delete dirToRemove;
    delete dirToRemove_file;
    DEBUG('q', "rmnode(): failure, directory isn't empty!\n");
    return FALSE;
  }

  filehdr->numLinks = filehdr->numLinks - 1;
  if (filehdr->numLinks == 0)
  {
    // original remove() code, before we supported hard links

    // Load the bit map of free disk blocks
    freelist = new BitMap(NumSectors);
    freelist->FetchFrom(freeMapFile);

    // delete space for its data blocks
    dirToRemove_file->hdr->Deallocate(freelist);

    // delete space for its header
    freelist->Clear(sectorNum);

    // delete the entry from the parent directoy
    if (rootDir->Remove(thisDir) == FALSE)
    {
      delete rootDir;
      delete filehdr;
      if (flag)
        delete directory_file;
      delete dirToRemove;
      delete dirToRemove_file;
      delete freelist;
      DEBUG('q', "rmnode(): failure, entry in parent dir not removed!\n");
      return FALSE;
    }

    // write changes back to bitmap back to disk
    freelist->WriteBack(freeMapFile);

    // write changes to parent directory back to disk
    rootDir->WriteBack(directory_file);

    // everything successful, let's cleanup the mess we've created
    delete rootDir;
    delete filehdr;
    if (flag)
      delete directory_file;
    delete dirToRemove;
    delete dirToRemove_file;
    delete freelist;
    DEBUG('q', "rmnode(): success, exiting function...\n");
    return TRUE;
  }
  else  // we cannot blow away the inode, other links exist
  {
    DEBUG('q', "rmnode(): other links exist, only dir entry is removed\n");
    filehdr->WriteBack(sectorNum);  // writeback the inode

    // delete the entry from the parent directoy
    if (rootDir->Remove(thisDir) == FALSE)
    {
      delete rootDir;
      delete filehdr;
      if (flag)
        delete directory_file;
      delete dirToRemove;
      delete dirToRemove_file;
      DEBUG('q', "rmnode(): failure, entry in parent dir not removed!\n");
      return FALSE;
    }

    // write changes to parent directory back to disk
    rootDir->WriteBack(directory_file);

    // everything successful, let's cleanup the mess we've created
    delete rootDir;
    delete filehdr;
    if (flag)
      delete directory_file;
    delete dirToRemove;
    delete dirToRemove_file;
    DEBUG('q', "RmNode(): success, exiting function...\n");
    return TRUE;
  }
} 

//----------------------------------------------------------------------
// FileSystem::List
//  List all the files in the file system directory.
//----------------------------------------------------------------------

void
FileSystem::List()
{
  Directory *directory = new Directory(NumRootDirEntries);

  directory->FetchFrom(rootDirFile);
  directory->List();
  delete directory;
}

//----------------------------------------------------------------------
// FileSystem::Link
//  This is the *fun* part of MP4. Link creates a hard link such that
//  the directory entry specified by the target paramater points to
//  the file header (or inode) pointed to by the directory entry
//  specified by source.
//
//  Return TRUE if the link was successfully created; return FALSE
//  otherwise.
//
//  THIS FUNCTION CAN LINK BOTH FILES AND DIRECTORIES
//
//  "target" - The fully qualified pathname of the directory entry to
//             be created.
//  "source" - The fully qualified pathname of the directory entry
//             pointing to the existing file header.
//----------------------------------------------------------------------

bool
FileSystem::Link(char *target, char *source)
{
  DEBUG('f', "Linking %s to %s.\n", target, source);

  // Implement for MP4.
  Directory *directory;
  int sector;
  int srcSector;
  char* thisDir;
  char* nextDir;
  char* srcName;
  FileHeader *hdr = new FileHeader;
  FileHeader *srcHdr;
  OpenFile* directory_file;
  bool flag = FALSE;

  Directory *directory2;
  OpenFile* directory_file2;
  bool flag2 = FALSE;

  // load the root directory
  directory = new Directory(NumRootDirEntries);
  directory->FetchFrom(rootDirFile);
  directory_file = rootDirFile;

  DEBUG('q', "link(): root dir table loaded, time to traverse...\n");

  /***** DIRECTORY TRAVERSAL CODE *****/
  thisDir = strtok(source,"/");  // get first directory name in the path
  nextDir = strtok(NULL,"/");  // get next directory name in the path
  while( nextDir != NULL )   // as long as this directory is not the end...
  {
    sector = directory->Find(thisDir);  // Look for the entry...
    if (sector == -1)
    {
      delete directory;  // thisDir does not exist, cannot traverse further
      delete hdr;
      DEBUG('q', "link(): cannot traverse, dir doesn't exist\n");
      return FALSE;      // failure to open a file
    }

    hdr->FetchFrom(sector);        // ...and verify it is a directory
    if (hdr->is_a_directory != TRUE)
    {
      delete directory;  // thisDir is NOT a directory!
      delete hdr;
      DEBUG('q', "link(): invaild path (dir is a file), cannot traverse\n");
      return FALSE;    // failure to open a file
    }

    if (flag)
      delete directory_file;

    directory_file = new OpenFile(sector);
    flag = TRUE;
    directory->FetchFrom(directory_file);
    strcpy(thisDir,nextDir);
    nextDir = strtok(NULL,"/");
    DEBUG('q', "link(): just finished a single traversal loop...\n");
  }
  /***** END DIRECTORY TRAVERSAL CODE *****/
  DEBUG('q', "link(): traversal complete!\n");


  // look for file
  srcSector = directory->Find(thisDir);
  if (srcSector == -1)
  {
    delete directory;
    delete hdr;
    if (flag)
      delete directory_file;
    DEBUG('q', "link(): source doesn't exist, can't link to it!\n");
    return FALSE;
  }

  DEBUG('q', "link(): we found source, store the sector # and name...\n");

  strcpy(srcName,thisDir);

  DEBUG('q', "link(): strcpy of srcName successful...\n");

  // At this point, we have found our source (inode & name).
  // Let's try to create "target", which will point to the "source" inode.
  // After we've added an entry in the parent dir of "target", we gotta
  // increment "numLinks" in the inode, writeback the inode, and writeback
  // the parent directory of "target".


  DEBUG('q', "link(): now we gotta deal with target...\n");


  // load the root directory
  directory2 = new Directory(NumRootDirEntries);
  directory2->FetchFrom(rootDirFile);

  DEBUG('q', "link(): we just fetched the root dir file\n");
  directory_file2 = rootDirFile;

  DEBUG('q', "link(): start 2nd traversal...\n");

  /***** DIRECTORY TRAVERSAL CODE *****/
  thisDir = strtok(target,"/");  // get first directory name in the path
  nextDir = strtok(NULL,"/");  // get next directory name in the path
  while( nextDir != NULL )   // as long as this directory is not the end...
  {
    sector = directory2->Find(thisDir);  // Look for the entry...
    if (sector == -1)
    {
      delete directory2;  // thisDir does not exist, cannot traverse further
      delete hdr;
      DEBUG('q', "link(): cannot traverse for target, dir doesn't exist\n");
      return FALSE;      // failure to open a file
    }

    hdr->FetchFrom(sector);        // ...and verify it is a directory
    if (hdr->is_a_directory != TRUE)
    {
      delete directory2;  // thisDir is NOT a directory!
      delete hdr;
      DEBUG('q', "link(): (dir is a file), cannot traverse target\n");
      return FALSE;    // failure to open a file
    }

    if (flag2)
      delete directory_file2;

    directory_file2 = new OpenFile(sector);
    flag2 = TRUE;
    directory2->FetchFrom(directory_file2);
    strcpy(thisDir,nextDir);
    nextDir = strtok(NULL,"/");
    DEBUG('q', "link(): just finished a single traversal loop (target)...\n");
  }
  /***** END DIRECTORY TRAVERSAL CODE *****/
  DEBUG('q', "link(): 2nd traversal complete!\n");


  // verify that "target" does not already exist
  if ( directory2->Find(thisDir) != -1)
  {
    delete directory2;
    delete hdr;
    if (flag2)
      delete directory_file2;
    DEBUG('q', "link(): failure, target already exists!\n");
    return FALSE;
  }

  DEBUG('q', "link(): passed uniqueness test\n");

  // add an entry in the parent dir of "target",
  // storing the sector and name of the "source" inode
  if ( directory2->Add(thisDir,srcSector) == FALSE )
  {
    delete directory2;         // no free directory entries left,
    delete hdr;               // cannot create the link
    if (flag2)
      delete directory_file2;
    DEBUG('q', "link(): failure, parent directory of target is full\n");
    return FALSE;
  }


  // increment "numLinks" in the inode
  srcHdr = new FileHeader;
  srcHdr->FetchFrom(srcSector);
  srcHdr->numLinks = srcHdr->numLinks + 1;
  DEBUG('q', "link(): numLinks has been incremented in the source inode\n");

  // writeback the inode
  srcHdr->WriteBack(srcSector);

  // writeback the parent directory of "target"
  directory2->WriteBack(directory_file2);

  delete directory2;
  delete hdr;
  delete srcHdr;
  if (flag2)
    delete directory_file2;

  DEBUG('q', "link(): success, exiting function...\n");

  return TRUE;
}

//----------------------------------------------------------------------
// FileSystem::Print
//  Print everything about the file system:
//    the contents of the bitmap
//    the contents of the directory
//    for each file in the directory,
//        the contents of the file header
//        the data in the file
//----------------------------------------------------------------------

void
FileSystem::Print()
{
  FileHeader *bitHdr = new FileHeader;
  FileHeader *dirHdr = new FileHeader;
  BitMap *freeMap = new BitMap(NumSectors);
  Directory *directory = new Directory(NumRootDirEntries);

  printf("Bit map file header:\n");
  bitHdr->FetchFrom(FreeMapSector);
  bitHdr->Print();

  printf("Directory file header:\n");
  dirHdr->FetchFrom(RootDirSector);
  dirHdr->Print();

  freeMap->FetchFrom(freeMapFile);
  freeMap->Print();

  directory->FetchFrom(rootDirFile);
  directory->Print();

  delete bitHdr;
  delete dirHdr;
  delete freeMap;
  delete directory;
} 
