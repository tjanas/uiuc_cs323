#include "syscall.h"

int
main()
{
    char prompt[7];
    int i;
    

    prompt[0] = 'd';
    prompt[1] = 'u';
    prompt[2] = 'm';
    prompt[3] = 'p';
    prompt[4] = 'e';
    prompt[5] = 'd';
    prompt[6] = '\n';

    Write(prompt, 7, ConsoleOutput); 

    TestCase(2);
    
    Halt();
}

