
#include "syscall.h"

#define PageSize 128
#define BIG PageSize*32

char s1[BIG],s2[BIG];

int
main()
{
    char prompt[8];
    int i;

    Write("abcde\n", 6, ConsoleOutput);

    prompt[0] = 'a';
    prompt[1] = 'b';
    prompt[2] = 'c';
    prompt[3] = 'd';
    prompt[4] = 'e';
    prompt[5] = 'f';
    prompt[6] = 'g';
    prompt[7] = '\n';

    TestCase(0);

    for (i = 0; i < BIG; i ++) {
      s1[i]=i%128;
      s2[i]=(i+64)%128;
    } 
    prompt[0]=prompt[1];
    /*Write(prompt,8,ConsoleOutput);*/

    TestCase(1);

    for (i=0; i<BIG; i++)
      s2[BIG-1-i]=s1[i];
    prompt[1]=prompt[2];
    /*Write(prompt,8,ConsoleOutput);*/

    TestCase(2);

    for (i=0; i<BIG; i++)
      s1[BIG-i]=s2[BIG-i];
    prompt[2]=prompt[3];
    /*Write(prompt,8,ConsoleOutput);*/

    TestCase(2);

    for (i=0; i<BIG; i++)
        s1[BIG-i]=s1[i]; 
    prompt[4]=prompt[5];
    /*Write(prompt,8,ConsoleOutput);*/

    TestCase(2);

    Halt(); 
}

