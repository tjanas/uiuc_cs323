#include "syscall.h"

int
main()
{
    char a[5];

    Write("start", 5, ConsoleOutput);

    a[0] = 't'; a[1] = 'e'; a[2] = 's'; a[3] = 't';
    Write(a, 4, ConsoleOutput);  

    TestCase(1);

    Halt();
}

