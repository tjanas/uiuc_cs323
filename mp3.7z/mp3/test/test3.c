
#include "syscall.h"

#define PageSize 128
#define BIG PageSize*32

char s1[BIG];

int main()
{
    char prompt[8];
    int i;

    prompt[0] = 's';
    prompt[1] = 't';
    prompt[2] = 'e';
    prompt[3] = 'p';
    prompt[4] = ' ';
    prompt[5] = '1';
    prompt[6] = '!';
    prompt[7] = '\n';

    for (i = 0; i < BIG; i ++)
    {
      s1[i]=i/PageSize;
    } 

    Write(prompt,8,ConsoleOutput);

    Halt(); 
}

