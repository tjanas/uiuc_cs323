// exception.h            -*- C++ -*-
// No files besides exception.cc ought to #include this file!

#include "thread.h"
#include "console.h"
#include "synch.h"
 
#define MaxNoThreads 20

int numThreadsExec = 0;
int joinInvoked = 0;
 
struct joinThreadList{
  Thread *threadExecuting[MaxNoThreads];
  Condition *completeThread[MaxNoThreads];
  Lock *completeLock[MaxNoThreads];
} joinThreadList;
 
int statusReturned[MaxNoThreads];
int threadComplete[MaxNoThreads];
static int threadsIn = 1;

static Console *console;
static Semaphore *readAvail;
static Semaphore *writeDone;
static Lock *writeLock;

static void ReadAvail(int arg)
{
  if (arg) {} // ignore arg, silence warning.
  readAvail->V();
}

static void WriteDone(int arg)
{
  if (arg) {} // ignore arg, silence warning.
  writeDone->V();
}

