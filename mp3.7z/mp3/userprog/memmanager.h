#ifndef MEMMANAGER_H
#define MEMMANAGER_H

#include "bitmap.h"
#include "translate.h"
#include "timer.h"

#define EMPTY_FRAME 1
#define CLEAN_FRAME 2
#define DIRTY_FRAME 3

// Arbitrary number:
#define NumSwapPages 4096
//#define BUFFERSIZE   5

class Semaphore;
template <class T> class List;
class Lock;

void PageTimer( int arg );

// indicated which page replacement policy
enum REPLACEMENT_POLICY
{
  PAGEREPL_NRU,   // not recently used
  PAGEREPL_FIFO,  // first in, first out
  PAGEREPL_SC,    // second chance
  PAGEREPL_CLOCK, // clock
  PAGEREPL_WS,   // working set
  PAGEREPL_AGING, // aging
};

class MemManager
{
public:
  MemManager( int pbuffer, int hbits ); // constructor
  ~MemManager(); // destructor

  ///////////////////////////////////////////////////////////////////
  // implemented in testcase.cc
  ///////////////////////////////////////////////////////////////////
  void display(void);  

  ///////////////////////////////////////////////////////////////////
  // Total memory in pages (includes swap pages)
  ///////////////////////////////////////////////////////////////////
  unsigned int memAvail();       // how much memory is free (in pages)

  ///////////////////////////////////////////////////////////////////
  // mark the first free page and return its index, or return -1
  // if no page is free
  ///////////////////////////////////////////////////////////////////
  int locateFirst();    
  
  ///////////////////////////////////////////////////////////////////
  // This will be invoked in AddrSpace destructor  by a dying 
  // process.  Hence it must free up all memory (physical + swap)
  ///////////////////////////////////////////////////////////////////
  void clear(TranslationEntry *pageTable, int numPages); // clear everything

  ///////////////////////////////////////////////////////////////////
  // move a page from physical memory to swap
  ///////////////////////////////////////////////////////////////////
  void pageOut(int physFrame);

  ///////////////////////////////////////////////////////////////////
  // move a page from swap to physical memory
  ///////////////////////////////////////////////////////////////////
  void pageIn(TranslationEntry *PTEntry, int physFrame);

  ///////////////////////////////////////////////////////////////////
  // MP3: Implements page buffering policy. Uses pagein and page out.
  ///////////////////////////////////////////////////////////////////
  void faultIn(TranslationEntry *PTEntry);

  ///////////////////////////////////////////////////////////////////
  // handle page faults
  ///////////////////////////////////////////////////////////////////
  void PageFaultExceptionHandler(int BadVPage);

  ///////////////////////////////////////////////////////////////////
  // timer interrupt service handler
  ///////////////////////////////////////////////////////////////////
  void doUpdation( int arg );

private:
  List<int *> *fifoList; // list of page references used for FIFO, SC
  Timer *hTimer; // used to generate interrupts for timing algorithms
  
  // described in memmanager.cc
  BitMap *coreFreeMap,*swapFreeMap,*swapValidMap;
  TranslationEntry **coreOwners,**swapOwners;

  OpenFile *swapfile; // holds the Nachos backing store
  
  Semaphore *mutex; // protects critical section in PageFaultExceptionHandler

  REPLACEMENT_POLICY policy; // used to indicate the policy in use

  int hbits; // number of bits to use in aging
  int bitmask; // use in aging
  unsigned int * history; // stores the bits used in aging
  int clock_hand; // number of page to be considered next under CLOCK
  
  ///////////////////////////////////////////////////////////////////
  // Make a free frame by using the appropriate algorithm
  ///////////////////////////////////////////////////////////////////
  int makeFreeFrame();
  
  // search the swap pages for the PTEntry object
  int swapSearch( TranslationEntry *PTEntry );
};
#endif // MEMMANAGER_H
