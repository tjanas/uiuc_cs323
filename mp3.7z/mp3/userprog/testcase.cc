/* userprog/testcase.cc

   This will contain the kernel-level code to test MP3.
*/

#include "system.h"
#include "machine.h"
#include "memmanager.h"

void MemManager::display(void) { 
  int i, j;

  printf ("\n\nPHYSICAL MEMORY DUMP:\n");
  printf("F = Frame Number\nV = Virtual Page Number\n");
  
  printf("F\t");
  for (i=0; i<NumPhysPages; i++)
  {
     printf("%2d ", i);
  }
  printf("\n");
  
  printf("V\t");
  for (i=0; i<NumPhysPages; i++)
  {
     if (coreFreeMap->Test(i))
     {
        if (coreOwners[i])
          printf("%2d ", coreOwners[i]->virtualPage);
        else
          printf(" E "); //empty frame
     }
     else
     {
        printf(" E "); //empty frame
     }
  }
  printf("\n");

  
  printf ("\n\nSWAP FILE DUMP:\n");
  printf("Format is [<swap frame>/<virtual page number>]\n");
  j=0;
  for (i=0; i<NumSwapPages; i++)
    if (swapFreeMap->Test(i)) {
      ASSERT(swapOwners[i]);
      j++;
      if (j % 6 == 0)
      {
         printf("[%d / %d]\n", i, swapOwners[i]->virtualPage);
      }
      else
      {
         printf("[%d / %d]  ", i, swapOwners[i]->virtualPage);
      }
    }

  printf ("\n\nTotal free pages: %d\n",memAvail());
  printf ("MemoryManager dump complete.\n");
  formatCount = 0;
}


void TestCase(int which_case) {
  int i;

  printf("\n\nOUTPUT FOR TESTCASE %d\n", which_case);
  switch (which_case) {
  case 0:
    // Display the state of main memory and swap file
    machine->memManager->display();
    break;

  case 1:
    // Dump the page table:
    printf ("\n\nPROGRAM PAGE TABLE CONTENTS:\n");
    for (i=0; i<currentThread->space->numPages; i++) {
      TranslationEntry *te=currentThread->space->pageTable+i;
      printf ("entry %d, phys %d, virt %d, %s, %s\n", i,
        te->physicalPage, te->virtualPage, te->legal?"legal":"illegal",
        te->valid?"valid":"invalid");
    }
    break;

  case 2:
    // Display the state of main memory and swap file
    // Dump the page table.
    machine->memManager->display();

    printf ("\n\nPROGRAM PAGE TABLE CONTENTS:\n");
    for (i=0; i<currentThread->space->numPages; i++) {
      TranslationEntry *te=currentThread->space->pageTable+i;
      printf ("entry %d, phys %d, virt %d, %s, %s\n", i,
        te->physicalPage, te->virtualPage, te->legal?"legal":"illegal",
        te->valid?"valid":"invalid");
    }
    break;

  default:
    printf ("Thread %8.8x (\"%s\") called for unimplemented test case %d\n",
            (int)currentThread,currentThread->getName(),which_case);
  }
}
