// oneshot.h
//  Routines to emulate a hardware one-shot timer device.
//
//      A one-shot hardware timer generates a CPU interrupt in X milliseconds.
//      The interrupt will only occur once and not ever X milliseconds.
//      This means it can be used for implementing time-slicing.
//
//  Remember -- nothing in here is part of Nachos.  It is just
//  an emulation for the hardware that Nachos is running on top of.
//
//  DO NOT CHANGE -- part of the machine emulation
//
//  Fall 2002 - CS 323 - University of Illinois at Urbana-Champaign
//
//  Adapted from NachOS' timer.cc.
//

#ifndef ONESHOT_H
#define ONESHOT_H

#include "copyright.h"
#include "utility.h"

// The following class defines a hardware one-shot timer. 
class OneShot
{
  public:
    OneShot(VoidFunctionPtr timerHandler, int callArg, int time);
        // Initialize the timer, to call the interrupt
        // handler "timerHandler" when the time expands.
    ~OneShot() {}

// Internal routines to the timer emulation -- DO NOT call these
    void TimerExpired();  // called internally when the hardware
        // timer generates an interrupt

  private:
    VoidFunctionPtr handler;  // timer interrupt handler 
    int arg;      // argument to pass to interrupt handler
};

#endif // ONESHOT_H
