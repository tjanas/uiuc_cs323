// ====================================================================== 
// Test the Condition class.
//

#include "system.h"
#include "synch.h"
#include "testcase.h"

static Condition* cond;
static Lock*      lock;

void ThreadWorkA( int )
{   
    lock->Acquire();

    printf( "(%s is waiting on the condition.)\n", currentThread->getName() );
    cond->Wait( lock );
    printf( "(%s has finished waiting on the condition.)\n", currentThread->getName() );

    for ( int i = 0; i < 3; i++ )
    {
        printf( "%s working...\n", currentThread->getName() );
        currentThread->Yield();
    }

    lock->Release();
}

void ThreadWorkB( int )
{
    lock->Acquire();

    printf( "(%s is waiting on the condition.)\n", currentThread->getName() );
    cond->Wait( lock );
    printf( "(%s has finished waiting on the condition.)\n", currentThread->getName() );


    for ( int i = 0; i < 3; i++ )
    {
        printf( "%s working...\n", currentThread->getName() );
        currentThread->Yield();
    }

    printf( "(%s is signalling the condition.)\n", currentThread->getName() );
    cond->Signal( lock );
    lock->Release();
}


void ThreadWorkC( int )
{   
    lock->Acquire(); 

    printf( "(%s is about to broadcast on the condition.)\n", currentThread->getName() );
    cond->Broadcast( lock );
    printf("... broadcast done!\n" );

    lock->Release(); 
}

void SynchTestCondition()
{
    scheduler->SetSchedPolicy(SCHED_FCFS);

    lock = new Lock( "condition lock" );
    cond = new Condition( "moreToDo" );

    Thread *t_1 = new Thread( "thread1" );
    Thread *t_2 = new Thread( "thread2" );
    Thread *t_3 = new Thread( "thread3" );
    Thread *t_4 = new Thread( "thread4" );
    Thread *t_5 = new Thread( "thread5" );


    t_1->Fork( ThreadWorkA, 0 );
    t_2->Fork( ThreadWorkA, 0 );
    t_3->Fork( ThreadWorkB, 0 );
    t_4->Fork( ThreadWorkC, 0 );
    t_5->Fork( ThreadWorkA, 0 );
}



//
// END.
//

