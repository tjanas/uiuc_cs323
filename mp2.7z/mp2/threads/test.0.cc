// ====================================================================== 
//  Test the Semaphore class.
//

#include "list.h"
#include "system.h"
#include "synch.h"
#include "testcase.h"

static Semaphore *controlSem;

static void ThreadWork( int s )
{
    Semaphore* sem = (Semaphore*) s;

    printf( "(%s is down-ing semaphore [%s].)\n", currentThread->getName(), sem->getName() );
    sem->down();
    printf( "===> CRITICAL SECTION: %s. <===\n", currentThread->getName() );
    currentThread->Yield();
    sem->up();
    printf( "(%s is up-ing the semaphore [%s].)\n", currentThread->getName(), sem->getName() );

    controlSem->up();
}

void SynchTestSemaphore()
{
    scheduler->SetSchedPolicy(SCHED_FCFS);
    controlSem = new Semaphore( "control", -3 );    // require 4 ups

    printf( "\nPart A\n" );
    Semaphore* workerSemA = new Semaphore( "workersA", 1 );

    Thread *t_1 = new Thread( "Thread1" );
    Thread *t_2 = new Thread( "Thread2" );
    Thread *t_3 = new Thread( "Thread3" );
    Thread *t_4 = new Thread( "Thread4" );

    t_1->Fork( ThreadWork, (int) workerSemA );
    t_2->Fork( ThreadWork, (int) workerSemA );
    t_3->Fork( ThreadWork, (int) workerSemA );
    t_4->Fork( ThreadWork, (int) workerSemA );

    /* wait for part A to complete */
    controlSem->down();

    printf( "\nPart B\n" );
    Semaphore* workerSemB = new Semaphore( "workersB", 2 );

    Thread *t_5 = new Thread( "Thread5" );
    Thread *t_6 = new Thread( "Thread6" );
    Thread *t_7 = new Thread( "Thread7" );
    Thread *t_8 = new Thread( "Thread8" );
    Thread *t_9 = new Thread( "Thread9" );

    t_5->Fork( ThreadWork, (int) workerSemB );
    t_6->Fork( ThreadWork, (int) workerSemB );
    t_7->Fork( ThreadWork, (int) workerSemB );
    t_8->Fork( ThreadWork, (int) workerSemB );
    t_9->Fork( ThreadWork, (int) workerSemB );
}



//
// END.
//

