// This switches among the various testcases...
#include <string.h>
#include <stdio.h>
#include "system.h"
#include "list.h"
#include "synch.h"
#include "testcase.h"

void ThreadTest(char *name)
{ 
  char *basename=strrchr(name,'/');

  if (basename!=NULL) // if there was a path to trim,
    name=basename+1;  // trim it (lose the '/' too).

  if ( strcmp(name, "test0") == 0 )
  {
    SynchTestSemaphore();
  }
  else if ( strcmp(name, "test1") == 0 )
  {
    SynchTestLock();
  }
  else if ( strcmp(name, "test2") == 0 )
  {
    SynchTestCondition();
  }
  else if ( strcmp(name, "test3") == 0 )
  {
    SynchTestInteraction();
  }
  else if ( strcmp(name, "test4") == 0 )
  {
    SynchTestElevator();
  }
  else
  {
    printf ("OOPS: I'm called %s ???\n",name);
  }
}
