#ifndef _CS323_EVENT_MANAGER_
#define _CS323_EVENT_MANAGER_
#include<pthread.h>
#include<unistd.h>

struct event {
   int event_id;
   int delay;  //used by event generator
   int process_time; //used by event processor
};


class EventManager {
  public:
     EventManager();
     ~EventManager();
     void PutEvent(struct event*p);
     int GetEvents(struct event*p[]);

  private:
     Queue *event_queue;
  //TO DO 
     pthread_mutex_t mutex;
     pthread_cond_t condition;
   
};


#endif
