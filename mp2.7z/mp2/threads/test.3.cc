// ======================================================================  
//  Test ElevatorCar-Passenger interaction.
//

#include "list.h"
#include "system.h"
#include "synch.h"
#include "testcase.h"

void SynchTestInteraction()
{
  scheduler->SetSchedPolicy(SCHED_RR);

  Thread*      t = 0;
  Passenger*   p = 0;
  ElevatorCar* c = 0;

  // make a car that will simply wait for a passenger to board
  c = new ElevatorCar( 1, 1, 0 /* not in service */ );
  t = new Thread( "ElevatorCar" );
  t->Fork( (VoidFunctionPtr) ElevatorCar::activate, (int) c );

  // now a passenger (this thread) rides the car
  p = new Passenger( "A", 1, 2 );
  p->ride( c );

  // going down this time...
  c = new ElevatorCar( 2, 10, 0 /* not in service */ );
  t = new Thread( "ElevatorCar" );
  t->Fork( (VoidFunctionPtr) ElevatorCar::activate, (int) c );
  p = new Passenger( "B", 10, 7 );
  p->ride( c );

  // a longer ride...
  c = new ElevatorCar( 3, 1, 0 /* not in service */ );
  t = new Thread( "ElevatorCar" );
  t->Fork( (VoidFunctionPtr) ElevatorCar::activate, (int) c );
  p = new Passenger( "C", 1, 10 );
  p->ride( c );
}



//
// END.
//

