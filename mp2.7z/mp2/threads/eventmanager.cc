#include <stdio.h>
#include "queue.h"
#include "eventmanager.h"

EventManager::EventManager()
{
   event_queue = new Queue();
   //TO DO
   pthread_mutex_init(&mutex, NULL);
   pthread_cond_init(&condition, NULL);
}

EventManager::~EventManager()
{
   delete event_queue;
   //TO DO
   pthread_mutex_destroy(&mutex);
   pthread_cond_destroy(&condition);
}

void EventManager::PutEvent(struct event*p)
{

   //TO DO:
   //
   pthread_mutex_lock(&mutex);
   while(event_queue->IsFull()){
       pthread_cond_wait(&condition, &mutex);
   }
   event_queue->Enqueue(p);
   pthread_cond_broadcast(&condition);
   pthread_mutex_unlock(&mutex);

}

int EventManager::GetEvents(struct event *p[])
{
   int i = 0;
   //TO DO:
   //
   pthread_mutex_lock(&mutex);
   
   while(event_queue->IsEmpty()){
      pthread_cond_wait(&condition, &mutex);
   }
   i=0;
   while(! event_queue->IsEmpty()){
      p[i] = (struct event*)event_queue->Dequeue();
      i++;
   }
   pthread_cond_broadcast(&condition);
   pthread_mutex_unlock(&mutex);

   return i;
}


