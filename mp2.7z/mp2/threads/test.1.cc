// ====================================================================== 
//  Test the Lock class.
//

#include "list.h"
#include "system.h"
#include "synch.h"
#include "testcase.h"

static Lock *lock;

static void ThreadWork( int )
{
    printf( "(%s is attempting to acquire the lock.)\n", currentThread->getName() );
    lock->Acquire();
    printf( "===> CRITICAL SECTION: %s. <===\n", currentThread->getName() );
    currentThread->Yield();
    lock->Release();
    printf( "(%s is releasing the lock.)\n", currentThread->getName() );
}

void SynchTestLock()
{
    scheduler->SetSchedPolicy(SCHED_FCFS);
    lock = new Lock( "lock" );

    Thread *t_1 = new Thread( "Thread1" );
    Thread *t_2 = new Thread( "Thread2" );
    Thread *t_3 = new Thread( "Thread3" );
    Thread *t_4 = new Thread( "Thread4" );

    t_1->Fork( ThreadWork, 0 );
    t_2->Fork( ThreadWork, 0 );
    t_3->Fork( ThreadWork, 0 );
    t_4->Fork( ThreadWork, 0 );
}



//
// END.
//

