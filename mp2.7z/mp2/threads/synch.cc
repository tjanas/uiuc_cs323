// synch.cc 
//    Routines for synchronizing threads.  Three kinds of
//    synchronization routines are defined here: semaphores, locks 
//       and condition variables (the implementation of the last two
//    are left to the reader).
//
// Any implementation of a synchronization routine needs some
// primitive atomic operation.  We assume Nachos is running on
// a uniprocessor, and thus atomicity can be provided by
// turning off interrupts.  While interrupts are disabled, no
// context switch can occur, and thus the current thread is guaranteed
// to hold the CPU throughout, until interrupts are reenabled.
//
// Because some of these routines might be called with interrupts
// already disabled (Semaphore::V for one), instead of turning
// on interrupts at the end of the atomic operation, we always simply
// re-set the interrupt state back to its original value (whether
// that be disabled or enabled).
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.
//
//
//   Modified by:     Terrence B. Janas <tjanas@uiuc.edu>
//   Assignment:      MP2: Thread Synchronization
//   Course:          CS 323 - Operating Systems Design
//   Institution:     University of Illinois at Urbana-Champaign
//   Date:            March 04, 2003


#include "copyright.h"
#include "synch.h"
#include "system.h"
#include "list.h"



//----------------------------------------------------------------------
// Semaphore::Semaphore
//    Initialize a semaphore, so that it can be used for synchronization.
//
//    "debugName" is an arbitrary name, useful for debugging.
//    "initialValue" is the initial value of the semaphore.
//----------------------------------------------------------------------

Semaphore::Semaphore(const char* debugName, int initialValue)
{
    name  = debugName;
    value = initialValue;
    queue = new List<Thread*>();
}

//----------------------------------------------------------------------
// Semaphore::Semaphore
//    De-allocate semaphore, when no longer needed.  Assume no one
//    is still waiting on the semaphore!
//----------------------------------------------------------------------

Semaphore::~Semaphore()
{
    delete queue;
}

//----------------------------------------------------------------------
// Semaphore::P  (synonym Semaphore::down)
//    Wait until semaphore value > 0, then decrement.  Checking the
//    value and decrementing must be done atomically, so we
//    need to disable interrupts before checking the value.
//
//    MP2 hints:
//    A thread is suspended by invoking Thread::Sleep. Note that this
//    assumes that interrupts are disabled when it is called. 
//----------------------------------------------------------------------

void Semaphore::P()
{
     IntStatus oldLevel = interrupt->SetLevel(IntOff);  // disable interrupts
    
     //
     // MP2: implement.
     //
     while (value <= 0) {                     // check value
       queue->Append(currentThread);          // maybe block and enqueue
       currentThread->Sleep();
     }
     value = value-1;                         // consume value

     (void) interrupt->SetLevel(oldLevel);    // re-enable interrupts
}

//----------------------------------------------------------------------
// Semaphore::V  (synonym Semaphore::up)
//    Increment semaphore value, waking up a waiter if necessary.
//    As with P(), this operation must be atomic, so we need to disable
//    interrupts.  
//
//    MP2 hints:
//    A thread is "woken up" by calling Scheduler::ReadyToRun(). This
//    call assumes that interrupts are disabled when it is called.
//----------------------------------------------------------------------

void Semaphore::V()
{
    IntStatus oldLevel = interrupt->SetLevel(IntOff);  // disable interrupts

    //
    // MP2: implement.
    //
    Thread *waiter;

    waiter = queue->Remove();               // dequeue
    if (waiter != NULL)                     // and
      scheduler->ReadyToRun(waiter);        // awaken, then
    value = value+1;                        // unconsume value

    (void) interrupt->SetLevel(oldLevel);   // re-enable interrupts
}





//----------------------------------------------------------------------
// Lock::Lock(char* debugName)
//      Initialize a lock, so that it can be used for synchronization.
//      Initially, unlocked.
//
//      "debugName" is an arbitrary name useful for debugging purposes.
//----------------------------------------------------------------------

Lock::Lock(const char* debugName) 
{
    name       = debugName;
    value      = 1;
    queue      = new List<Thread*>();
    lockHolder = NULL;    // no thread yet holds lock
}

//----------------------------------------------------------------------
// Lock::~Lock()
//      De-allocate lock, when no longer needed.  Assume no one
//      is still waiting on the lock!
//----------------------------------------------------------------------

Lock::~Lock() 
{
    delete queue;
}

//----------------------------------------------------------------------
// Lock::Acquire()
//      Atomically wait until the lock is free, then set it to busy.
//      Equivalent to Semaphore::down(), with the semaphore value of 0
//      equal to busy, and semaphore value of 1 equal to free.
//----------------------------------------------------------------------

void Lock::Acquire()
{
    IntStatus oldLevel = interrupt->SetLevel(IntOff); // disable interrupts

    //
    // MP2: implement.
    //
    while(value <= 0) {              // wait until lock is free...
      queue->Append(currentThread);  // lock is aquired, so we
      currentThread->Sleep();        // go to sleep
    }
                                     // lock is now free

    value = 0;                       // so let's aquire the lock
    lockHolder = currentThread;      // and set it to BUSY

    (void) interrupt->SetLevel(oldLevel); // re-enable interrupts
}


//----------------------------------------------------------------------
// Lock::Release
//    Atomically set lock to be free, waking up a thread waiting
//    for the lock, if any.
//    Equivalent to Semaphore::up(), with the semaphore value of 0
//    equal to busy, and semaphore value of 1 equal to free.
//
//    By convention, only the thread that acquired the lock
//    may release it.
//---------------------------------------------------------------------

void Lock::Release()
{
    // only the thread that acquired the lock may release it
    ASSERT( isHeldByCurrentThread() );
  
    IntStatus oldLevel = interrupt->SetLevel(IntOff);  // disable interrupts

    //
    // MP2: implement.
    //
    Thread* waiter = queue->Remove();       // if a thread is waiting
    if (waiter != NULL)                     // wake it up and make it
      scheduler->ReadyToRun(waiter);        // ready to run
    value = 1;
    lockHolder = NULL;                      // lock is now free

    (void) interrupt->SetLevel(oldLevel);   // re-enable interrupts
}



//----------------------------------------------------------------------
// Lock::isHeldByCurrentThread()
//      Returns true if currentThread is the holder of the lock.
//      Interrupts should be disabled here.
//----------------------------------------------------------------------

bool Lock::isHeldByCurrentThread()
{
    bool returnValue;

    IntStatus oldLevel = interrupt->SetLevel(IntOff);
    returnValue = ( lockHolder == currentThread );
    (void) interrupt->SetLevel(oldLevel);

    return returnValue;
}





//----------------------------------------------------------------------
// Condition::Condition
//  Initialize a condition variable, so that it can be 
//  used for synchronization.  Initially, no one is waiting
//  on the condition.
//
//  "debugName" is an arbitrary name, useful for debugging.
//----------------------------------------------------------------------

Condition::Condition(const char* debugName)
{
    name       = debugName;
    numWaiters = 0;
    waitQueue  = new List<Semaphore *>;
}

//----------------------------------------------------------------------
// Condition::~Condition
//  Deallocate the data structures implementing a condition variable.
//----------------------------------------------------------------------

Condition::~Condition()
{
    delete waitQueue;
}

//----------------------------------------------------------------------
// Condition::Wait
//  Atomically release monitor lock and go to sleep.
//  Our implementation uses semaphores to implement this, by
//  allocating a semaphore for each waiting thread.  The signaller
//  will up() this semaphore, so there is no chance the waiter
//  will miss the signal, even though the lock is released before
//  calling down().
//
//  Note: we assume Mesa-style semantics, which means that the
//  waiter must re-acquire the monitor lock when waking up.
//
//  "conditionLock" -- lock protecting the use of this condition
//----------------------------------------------------------------------

void Condition::Wait(Lock* conditionLock)
{
    ASSERT(conditionLock->isHeldByCurrentThread());

    //
    // MP2: implement.
    //
    Semaphore *semaphore = new Semaphore(name, 0);

    // allocate semaphore for each waiting thread
    waitQueue->Append(semaphore);

    numWaiters++;              // One more thread waiting on the condition.
    conditionLock->Release();  // Automatically release monitor lock
    semaphore->P();            //  and go to sleep.
    conditionLock->Acquire();  // Waiter must re-acquire lock when waking up.

}

//----------------------------------------------------------------------
// Condition::Signal
//  Wake up a thread waiting on this condition, if any.
//
//  Note: we assume Mesa-style semantics, which means that the
//  signaller doesn't give up control immediately to the thread
//  being woken up (unlike Hoare-style).
//
//  Also note: we assume the caller holds the monitor lock
//  (unlike what is described in Birrell's paper).  This allows
//  us to access waitQueue without disabling interrupts.
//
//  "conditionLock" -- lock protecting the use of this condition
//----------------------------------------------------------------------

void Condition::Signal(Lock* conditionLock)
{
    ASSERT(conditionLock->isHeldByCurrentThread());

    //
    // MP2: implement.
    //
    Semaphore *semaphore = waitQueue->Remove();
    if (semaphore != NULL) {
      numWaiters--;           // Wake up a thread waiting on
      semaphore->V();         // this condition, if any.
    }
}

//----------------------------------------------------------------------
// Condition::Broadcast
//     Wake up all threads waiting on this condition, if any.
//
//     "conditionLock" -- lock protecting the use of this condition
//----------------------------------------------------------------------

void Condition::Broadcast(Lock* conditionLock)
{
    //
    // MP2: implement.
    //
    Semaphore *semaphore = waitQueue->Remove();
    while (semaphore != NULL) {         // Wake up all the threads
      numWaiters--;                     // waiting on this condition.
      semaphore->V();
      semaphore = waitQueue->Remove();
    }
}





// ======================================================================
// Elevator simulation.
// ======================================================================





// ====================================================================== 
// class Idle
//

Idle::Idle() :
    mySem( "idle", 0 )
{
}

Idle::~Idle()
{
}

void Idle::operator ()( int ticks )
{
    interrupt->Schedule( Idle::done, (int) this, ticks, TimerInt );
    mySem.down();
}

void Idle::done( int idler )
{
    ( (Idle*) idler )->mySem.up();
}





// ====================================================================== 
// class Passenger
//

// ---------------------------------------------------------------------- 
// thread execution entry point.
//

void Passenger::activate( int person )
{
    // hacky - imposed by the Thread->Fork(..) interface
    ( (Passenger*) person )->run();
}


void Passenger::run()
{
    logmsg( SUMMONING );

    //
    // MP2: implement passenger run functionality here.
    //      (Part 2 of elevator simulation only.)
    //

    // The Passenger summons an ElevatorCar to ride...
    ElevatorCar* car = Elevator::instance()->summon(myCurrFloor);

    // ...and then she rides that ElevatorCar!
    ride(car);

    logmsg( LEAVING );
}



// ---------------------------------------------------------------------- 
// construction, etc.
//

Passenger::Passenger( const char* name, int atFloor, int toFloor ) :
    myName( name )
  , myCurrFloor( atFloor )
  , myDestFloor( toFloor )
  , myCarNumber( -1 )
{
    logmsg( BORN );
}

Passenger::~Passenger() { }



// ---------------------------------------------------------------------- 
// interaction with elevator cars.
//

void Passenger::ride( ElevatorCar* car )
{
    myCarNumber = car->getNumber();

    logmsg( STEPPING_IN );

    //
    // MP2: interaction with an elevator car starts here.
    //      (Parts 1 and 2 of elevator simulation.)
    //
    car->pushButton(myDestFloor);  // Tell the car to move to destination.
    myCurrFloor = myDestFloor;     // After returning from pushButton, we
                                   //  should be at the destination floor.
    logmsg( STEPPING_OUT );        // Step out of car.
}



// ---------------------------------------------------------------------- 
// misc.
//

const char* Passenger::getName() const
{
    return myName;
}

int Passenger::getCarNumber() const
{
    return myCarNumber;
}

void Passenger::logmsg( int msgId )
{
    switch ( msgId )
    {
    case BORN:
        printf( "[%.5d] Passenger [%s] created; will use elevator from floor [%d] to [%d].\n", stats->totalTicks, myName, myCurrFloor, myDestFloor );
        break;

    case SUMMONING:
        printf( "[%.5d] Passenger [%s] summoning car on floor [%d].\n", stats->totalTicks, myName, myCurrFloor );
        break;

    case LEAVING:
        printf( "[%.5d] Passenger [%s] done with elevator.\n", stats->totalTicks, myName );
        break;

    case STEPPING_IN:
        printf( "[%.5d] Passenger [%s] stepping into car [%d] on floor [%d].\n", stats->totalTicks, myName, myCarNumber, myCurrFloor );
        break;

    case STEPPING_OUT:
        printf( "[%.5d] Passenger [%s] stepping out of car [%d] on floor [%d].\n", stats->totalTicks, myName, myCarNumber, myCurrFloor );
        break;

    default:
        printf( "OOPS! Unrecognized passenger log message identifier [%d].", msgId );
    }
}





// ====================================================================== 
// class ElevatorCar
//

// ---------------------------------------------------------------------- 
// entry point for thread execution.
//

void ElevatorCar::activate( int car )
{
    // hacky - imposed by the Thread->Fork(..) interface.
    ( (ElevatorCar*) car )->run();
}

void ElevatorCar::run()
{
    if ( amInService )
    {
        // (for Part 2 of elevator simulation only.)
        logmsg( STARTING_SERVICE );
        operationLoop();
        logmsg( ENDING_SERVICE );
    }
    else
    {
        // (for Part 1 of elevator simulation only.)
        logmsg( PICKUP_PASSENGER );
        waitPassenger();  // we wait for the passenger to press button,
                          // then wait for the car to arrive at destination
        logmsg( UNLOAD_PASSENGER );
    }
}



// ---------------------------------------------------------------------- 
// construction, etc.
//

ElevatorCar::ElevatorCar( int id, int floor, int inService ) :
    myCarNumber( id )
  , myCurrFloor( floor )
  , myDestFloor( floor )
  , myDirection( 1 )
  , amInService( inService )
  , passingTime()
  //
  // MP2: any additional member initializers here.
  //
  , elevatorButton("ElevatorButton", 0)  // MP2 semaphore initialization
  , elevatorBell("ElevatorBell", 0)      // MP2 semaphore initialization
  , arrivalStatus( 0 )               // status returned by Elevator::arrive()
{
    //
    // MP2: perhaps some additional initialization here.
    //

    logmsg( BORN );
}

ElevatorCar::~ElevatorCar() { }



// ---------------------------------------------------------------------- 
// passenger thread entry point.
//

void ElevatorCar::pushButton( int toFloor )
{
    // 
    // MP2: interaction with a passenger starts here.
    //
    myDestFloor = toFloor;
    elevatorButton.V();  // Signal the ElevatorCar to move, then
    elevatorBell.P();    // sleep until car signals our arrival.

}



// ---------------------------------------------------------------------- 
// misc.
//

int ElevatorCar::getNumber() const
{
    return myCarNumber;
}



// ---------------------------------------------------------------------- 
// private helpers.
//

void ElevatorCar::operationLoop()
{
    while ( Elevator::instance()->operational() )
    {
        //
        // MP2: implement the elevator car in-service control loop here.
        //      (Part 2 of elevator simulation only.)
        //
        arrivalStatus = Elevator::instance()->arrive(myCurrFloor, this);
        if (arrivalStatus == 0)
          // no one waiting on the current floor, so goto next floor
          gotoNextFloor();
        else
          // passenger is about to board the car, so wait
          waitPassenger();
    }
}

void ElevatorCar::waitPassenger()
{
    //
    // MP2: implement interaction with a passenger here.
    //      (Parts 1 and 2 of elevator simulation.)
    //
    elevatorButton.P(); // wait until passenger has signaled us to move
    gotoDestFloor();    // ...move the elevator car...
    elevatorBell.V();   // we're at the destFloor, so signal the Passenger
}

void ElevatorCar::gotoDestFloor()
{
    int direction = ( myDestFloor < myCurrFloor ? -1 : 1 );
    int stillToGo = ( direction < 0 ? myCurrFloor - myDestFloor : myDestFloor - myCurrFloor ) - 1;

    passingTime( 1 );

    while ( stillToGo > 0 )
    {
        passingTime( 1 );
        myCurrFloor = myDestFloor - (direction * stillToGo);
        logmsg( MOVING );

        stillToGo -= 1;
    }

    myCurrFloor = myDestFloor;
    myDirection = direction;
    logmsg( ARRIVED );
}

void ElevatorCar::gotoNextFloor()
{
    myDestFloor = myCurrFloor + myDirection;

    if ( myDestFloor < Elevator::instance()->loFloor() )
    {
        myDirection = 1;
        myDestFloor = Elevator::instance()->loFloor() + 1;
    }

    if ( myDestFloor > Elevator::instance()->hiFloor() )
    {
        myDirection = -1;
        myDestFloor = Elevator::instance()->hiFloor() - 1;
    }

    passingTime( 1 );
    myCurrFloor = myDestFloor;
    logmsg( STEPPING );
}

void ElevatorCar::logmsg( int msgId )
{
    switch( msgId )
    {
    case BORN:
        printf( "[%.5d] Car [%d] created at floor [%d].\n", stats->totalTicks, myCarNumber, myCurrFloor );
        break;

    case STARTING_SERVICE:
        printf( "[%.5d] Car [%d] entering service on floor [%d].\n", stats->totalTicks, myCarNumber, myCurrFloor );
        break;

    case ENDING_SERVICE:
        printf( "[%.5d] Car [%d] leaving service on floor [%d].\n", stats->totalTicks, myCarNumber, myCurrFloor );
        break;

    case PICKUP_PASSENGER:
        printf( "[%.5d] Car [%d] waiting for passenger on floor [%d].\n", stats->totalTicks, myCarNumber, myCurrFloor );
        break;

    case UNLOAD_PASSENGER:
        printf( "[%.5d] Car [%d] dropping off passenger on floor [%d].\n", stats->totalTicks, myCarNumber, myCurrFloor );
        break;

    case MOVING:
        printf( "[%.5d] ... Car [%d] passing floor [%d].\n", stats->totalTicks, myCarNumber, myCurrFloor );
        break;

    case ARRIVED:
        printf( "[%.5d] ... Car [%d] arrived at floor [%d].\n", stats->totalTicks, myCarNumber, myCurrFloor );
        break;

    case STEPPING:
        printf( "[%.5d] Car [%d] stepped to floor [%d].\n", stats->totalTicks, myCarNumber, myCurrFloor );
        break;

    default:
        printf( "OOPS! Unrecognized elevator car log message identifier [%d].", msgId );
    }
}





// ====================================================================== 
// class Elevator.
//

Elevator* Elevator::theInstance = 0;



// ---------------------------------------------------------------------- 
// construction, etc.
//

void Elevator::activate( int floors, int cars )
{
    theInstance = new Elevator( floors, cars );
    theInstance->amWorking = 1;
}

void Elevator::shutdown()
{
    theInstance->amWorking = 0;
}

Elevator* Elevator::instance()
{
    return theInstance;
}

Elevator::Elevator( int floors, int cars ) :
    myLoFloor( 1 )
  , myHiFloor( floors )
  , myNumCars( cars )
  , amWorking( 0 )
  //
  // MP2: additional member initializers here.
  //
{
    //
    // MP2: perhaps some more initialization here.
    //
    // Initialize the passenger condition variable for each floor,
    // and the lists of waiting ElevatorCars for each floor.
    int i = 0;
    while (i < MAX_FLOORS) {
      waitingPassengers[i] = new Condition("FloorPassengers");
      queue[i] = new List<ElevatorCar*>();
      i++;
    }
    monitorLock = new Lock("monitorLock");
}

Elevator::~Elevator() 
{ 
     //
     // MP2: clean up here.
     //
     int i = 0;
     while (i < MAX_FLOORS) {
       delete waitingPassengers[i];  // deallocate Passenger queue
       delete queue[i];              // deallocate ElevatorCar queue
       i++;
     }
     delete monitorLock;
}



// ---------------------------------------------------------------------- 
// monitor entry points
//

ElevatorCar* Elevator::summon( int floor )
{
    //
    // MP2: implement passenger's entry to the monitor.
    //      (Part 2 of elevator simulation only.)
    //
    monitorLock->Acquire();      // monitor must ensure mutual exclusion

    waitingPassengers[floor-1]->Wait(monitorLock);  // wait for a signal

    // give an available ElevatorCar to a waiting passenger
    ElevatorCar* car = queue[floor-1]->Remove();

    monitorLock->Release();      // give up the monitor
    return car;                  // deliver the ElevatorCar to the Passenger
}

int Elevator::arrive( int floor, ElevatorCar* car )
{
    //
    // MP2: implement elevator car's entry to the monitor
    //      (Part 2 of elevator simulation only.)
    //

    monitorLock->Acquire();  // monitor must ensure mutual exclusion

    // If there are no passengers on this floor, then return 0 and let
    // the operationLoop() move the elevator to the next floor... 
    if ( waitingPassengers[floor-1]->getWaitCount() == 0 ) {
      monitorLock->Release();
      return 0;
    }

    // There is at least one passenger waiting on this floor...
    // Store the car pointer, so the awakened Passenger thread can use
    // it later for pushButton().
    else {
      queue[floor-1]->Append(car);
      waitingPassengers[floor-1]->Signal(monitorLock);

      monitorLock->Release();  // Let the signaled passenger have access.

      return 1;               // Let operationLoop() know we'll be waiting
    }                         // for a pushButton() call...

}



// ---------------------------------------------------------------------- 
// utilities.
//

int Elevator::operational() const
{
    return amWorking;
}

int Elevator::loFloor() const
{
    return myLoFloor;
}

int Elevator::hiFloor() const
{
    return myHiFloor;
}





//
// END.
//

