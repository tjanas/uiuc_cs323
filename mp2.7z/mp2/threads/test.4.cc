// ======================================================================  
// Test Elevator simulation.
//

#include "system.h"
#include "synch.h"
#include "testcase.h"

static const int   NUM_CARS   = 5;
static const int   NUM_RIDING = 10;

static const int   C_FLOORS[]  = { 1, 1, 1, 1, 1 };
static const char* P_NAMES[]   = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J" };
static const int   P_FLOORS[]  = {  2 ,  3 ,  4 ,  7 ,  9 ,  9 ,  6 ,  4 ,  2 ,  2  };
static const int   P_TARGETS[] = {  3 ,  1 ,  1 ,  1 ,  8 ,  6 ,  4 ,  9 ,  9 ,  5  };

static Semaphore* s = new Semaphore( "sim-active", 0 );

static void clockSimulation( int maxTicks );

void SynchTestElevator()
{
  scheduler->SetSchedPolicy(SCHED_RR);

  // don't start anything until the clocking says it's safe.
  Thread* clock = new Thread( "simulator" );
  clock->Fork( (VoidFunctionPtr) clockSimulation, 10000 );
  s->down();

  // make the cars
  int i = 0;
  while ( i < NUM_CARS )
  {
      ElevatorCar* c = new ElevatorCar( i, C_FLOORS[i], 1 /* in service */ );
      Thread*      t = new Thread( "ElevatorCar" );
      t->Fork( (VoidFunctionPtr) ElevatorCar::activate, (int) c );

      i += 1;
  }

  // make the people
  int j = 0;
  while ( j < NUM_RIDING )
  {
      Passenger* p = new Passenger( P_NAMES[j], P_FLOORS[j], P_TARGETS[j] );
      Thread*    t = new Thread( "Passenger" );
      t->Fork( (VoidFunctionPtr) Passenger::activate, (int) p );

      j += 1;
  }

}

static void clockSimulation( int maxTicks )
{
    Elevator::activate( 10, 1 );
    s->up();

    while ( stats->totalTicks < maxTicks )
    {
       interrupt->OneTick();
    }

    Elevator::shutdown();
}



//
// END.
//

