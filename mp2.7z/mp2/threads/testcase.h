// testcase.h 


#ifndef TESTCASE_H
#define TESTCASE_H

void SynchTestSemaphore();
void SynchTestLock();
void SynchTestCondition();
void SynchTestInteraction();
void SynchTestElevator();

#endif // TESTCASE_H
