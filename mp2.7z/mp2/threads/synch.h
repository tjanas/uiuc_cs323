// synch.h 
//    Data structures for synchronizing threads.
//
//    Three kinds of synchronization are defined here: semaphores,
//    locks, and condition variables.  The implementation for
//    semaphores is given; for the latter two, only the procedure
//    interface is given -- they are to be implemented by you.
//
//    Note that all the synchronization objects take a "name" as
//    part of the initialization.  This is solely for debugging purposes.
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// synch.h -- synchronization primitives.  
//
//
//   Modified by:     Terrence B. Janas <tjanas@uiuc.edu>
//   Assignment:      MP2: Thread Synchronization
//   Course:          CS 323 - Operating Systems Design
//   Institution:     University of Illinois at Urbana-Champaign
//   Date:            March 04, 2003


#ifndef SYNCH_H
#define SYNCH_H

#include "copyright.h"
#include "thread.h"
#include "list.h"



// ---------------------------------------------------------------------- 
// The following class defines a "semaphore" whose value is a non-
// negative integer.  The semaphore has only two operations:
//
//    P() -- waits until value > 0, then decrement.  Analagous to 
//           "down" in Tanenbaum
//
//    V() -- increment, waking up a thread waiting in P() if 
//           necessary. Analagous to "up" in Tanenbaum
// 
// Note that the interface does *not* allow a thread to read the value of 
// the semaphore directly -- even if you did read the value, the
// only thing you would know is what the value used to be.  You don't
// know what the value is now, because by the time you get the value
// into a register, a context switch might have occurred,
// and some other thread might have called P or V, so the true value 
// might now be different.
// ---------------------------------------------------------------------- 

class Semaphore {
public:
    Semaphore(const char* debugName, int initialValue); // set initial value
    ~Semaphore();                                       // de-allocate semaphore

    const char* getName() const { return name; }        // debugging assist
    
    // standard semamphore operations; both are atomic units of work.
    void P();     // proberen
    void V();     // verhogen

    // making compatible with Tanenbaum.
    void down() { P(); }
    void up()   { V(); }

    int getValue() const { return value; }              // cast to an int
    
private:
    const char*    name;     // for debugging
    int            value;    // semaphore value, always >= 0
    List<Thread*>* queue;    // threads waiting in P() for the value to be > 0
};





// ---------------------------------------------------------------------- 
// The following class defines a "lock".  A lock can be BUSY or FREE.
// There are only two operations allowed on a lock: 
//
//    Acquire -- wait until the lock is FREE, then set it to BUSY
//
//    Release -- set lock to be FREE, waking up a thread waiting
//                 in Acquire if necessary
//
// In addition, and by convention, only the thread that acquired the 
// lock may release it. As with semaphores, you can't read the lock 
// value (because the value might change immediately after you read it).  
// The isHeldByCurrentThread() member function is useful for checking in
// Release(), and in Condition operations.
// ---------------------------------------------------------------------- 

class Lock
{
public:
    Lock(const char* debugName);        // initialize lock to be FREE
    ~Lock();                            // deallocate lock

    const char* getName() { return name; }    // debugging assist
  
    // standard lock operations, both atomic.
    void Acquire();
    void Release();
  
    // true if the current thread holds this lock
    bool isHeldByCurrentThread(); 
  
private:
    const char*    name;                // lock name for debugging purposes
    int            value;
    List<Thread*>* queue;
    Thread*        lockHolder;          // thread currently holding lock
};





// ---------------------------------------------------------------------- 
// The following class defines a "condition variable".  A condition
// variable does not have a value, but threads may be queued, waiting
// on the variable.  These are only operations on a condition variable: 
//
//    Wait() -- release the lock, relinquish the CPU until signaled, 
//              then re-acquire the lock
//
//    Signal() -- wake up a thread, if there are any waiting on 
//                the condition
//
//    Broadcast() -- wake up all threads waiting on the condition
//
// All operations on a condition variable must be made while
// the current thread has acquired a lock. Indeed, all accesses
// to a given condition variable must be protected by the same lock.
// In other words, mutual exclusion must be enforced among threads 
// calling the condition variable operations.
//
// In Nachos, condition variables are assumed to obey *Mesa*-style
// semantics.  When a Signal or Broadcast wakes up another thread,
// it simply puts the thread on the ready list, and it is the
// responsibility of the woken thread to re-acquire the lock (this 
// re-acquire is taken care of within Wait()).  By contrast, some define 
// condition variables according to *Hoare*-style semantics -- where the
// signalling thread gives up control over the lock and the CPU to the 
// woken thread, which runs immediately and gives back control over the 
// lock to the signaller when the woken thread leaves the critical 
// section.
//
// The consequence of using Mesa-style semantics is that some other 
// thread can acquire the lock, and change data structures, before the 
// woken thread gets a chance to run.
// ---------------------------------------------------------------------- 

class Condition {
public:
    Condition(const char* debugName);    // initialize condition to "no one waiting"
    ~Condition();                        // deallocate the condition

    const char* getName()      { return name;       }
    int         getWaitCount() { return numWaiters; }
  
    // three standard condition variable operations.
    void Wait(Lock *conditionLock);      // lock is released, and then re-acquired
    void Signal(Lock *conditionLock);    // conditionLock must be held by
    void Broadcast(Lock *conditionLock); // Wake up all threads waiting on this condition
  
private:
    const char*       name;
    int               numWaiters;
    List<Semaphore*>* waitQueue;
};






// ======================================================================
// Elevator simulation.
// ======================================================================

// ---------------------------------------------------------------------- 
// class Idle.
// 

class Idle
{
public:
    Idle();
    ~Idle();

    // caller is blocked for the specified number of ticks.
    void operator ()( int ticks );

private:
    Semaphore mySem;
    static void done( int idler );
};



// ---------------------------------------------------------------------- 
// class Passenger.
//

class ElevatorCar;

class Passenger
{
public:
    Passenger( const char* name, int atFloor, int toFloor );
    ~Passenger();

    const char* getName() const;
    int         getCarNumber() const;

    void ride( ElevatorCar* car );

    // thread execution entry point; messy, but unavoidable.
    static void activate( int person );
    void run();

private:
    const char* myName;         // everyone has a name
    int         myCurrFloor;    // the floor at which self starts
    int         myDestFloor;    // the floor to which self will ride
    int         myCarNumber;    // the car servicing self's trip

    // logging utility
    void logmsg( int msgId );

    // log message identifiers
    static const int BORN         = 0;
    static const int SUMMONING    = 1;
    static const int LEAVING      = 2;
    static const int STEPPING_IN  = 3;
    static const int STEPPING_OUT = 4;
};



// ---------------------------------------------------------------------- 
// class ElevatorCar.
//

class ElevatorCar
{
public:
    ElevatorCar( int id, int floor, int inService );
    ~ElevatorCar();

    int getNumber() const;

    // control the car's motion.
    void pushButton( int toFloor );

    // thread execution entry point; messy, but unavoidable.
    static void activate( int car );
    void run();

private:
    int       myCarNumber;
    int       myCurrFloor;
    int       myDestFloor;
    int       myDirection;
    int       amInService;
    Idle      passingTime;

    //
    // MP2: you'll need additional member variables
    //
    Semaphore elevatorButton; // Passenger signals Car to move
    Semaphore elevatorBell;   // Car signals Passenger that we arrived

    int arrivalStatus;    // returned by Elevator::arrive()
                          //  = 1 if passengers are waiting at current floor
                          //  = 0 otherwise

    void operationLoop();
    void waitPassenger();
    void gotoNextFloor();
    void gotoDestFloor();

    // logging utility
    void logmsg( int msgId );

    // log message identifiers
    static const int BORN             = 0;
    static const int STARTING_SERVICE = 1;
    static const int ENDING_SERVICE   = 2;
    static const int PICKUP_PASSENGER = 3;
    static const int UNLOAD_PASSENGER = 4;
    static const int MOVING           = 5;
    static const int ARRIVED          = 6;
    static const int STEPPING         = 7;
};



// ---------------------------------------------------------------------- 
// class Elevator.
//

class Elevator
{
public:
    static void activate( int floors, int cars );
    static void shutdown();

    static Elevator* instance();

    // monitor entry points.
    ElevatorCar* summon( int floor );
    int          arrive( int floor, ElevatorCar* car );

    // utility.
    int operational() const;
    int loFloor() const;
    int hiFloor() const;

private:
    Elevator( int floors, int cars );
    ~Elevator();

    static Elevator* theInstance;

    static const int MAX_FLOORS = 100;

    int myLoFloor;
    int myHiFloor;
    int myNumCars;
    int amWorking;

    //
    // MP2: you'll need addition member variables
    //

    // A condition variable for each floor, where passengers are blocked
    // at each floor until a car arrives.
    Condition* waitingPassengers[MAX_FLOORS];


    // When an elevatorCar arrives at a floor with passengers waiting,
    // it should register itself with the elevator as being present and
    // waiting at that floor. Car is removed from the floor's list once
    // a Passenger begins to board.
    List<ElevatorCar*>* queue[MAX_FLOORS];


    // Elevator must ensure mutal exclusion, serves as a monitor.
    // No two threads of control should be permitted to execute within
    // the monitor concurrently.
    Lock* monitorLock;
};



#endif // SYNCH_H

